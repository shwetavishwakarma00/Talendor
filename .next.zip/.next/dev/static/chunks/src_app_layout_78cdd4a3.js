(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a3dce129._.css",
  "static/chunks/node_modules_next_ec1c52de._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_0a78009b._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_ti_index_mjs_f5c17cc1._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/src_3ee8a791._.js"
],
    source: "dynamic"
});
