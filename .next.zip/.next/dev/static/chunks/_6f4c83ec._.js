(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/data/founders.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"founders":[{"name":"Anita Chandola","title":"Executive Search Consultant","slug":"anita-chandola","description":["Anita has spent nearly 15 years to find best fit talent for organizations from different industries including FMCG, Hospitality, Management Consulting, Banking, Aviation, etc.","Anita is a passionate Executive Search Consultant and loves to spend time with family, friends and singing."],"image":"/images/anita_chandola.webp","experienceSummary":["With 20+ years of global HR experience, Praveen is passionate about people and organizational development, he has held key roles including Head HR, HR Business Partner across India, APAC, Middle East, Russia, and Latin America, and Global HR CoE Leader at Sennheiser.","Expert in building scalable processes, driving global talent strategies, and enabling cultural and organizational transformation.","Self-driven, self-aware, nature and adventure lover with continuous learning mindset and humble attitude.","Foundation Team member of India entity & build HR foundations across regions.","Led, developed & implemented global talent, leadership, and performance programs.","Driven multiple large global culture transformation and org redesign.","Successfully planned & executed complex business M&A & carve-outs.","Delivered HR digital transformation via HRIS, LMS & Intranet.","Core Global team member of DEI, wellbeing, and sustainability initiatives.","Enhanced talent acquisition, retention, and L&D impact.","Trusted partner to business leaders, aligning HR & business strategy."],"continuousLearning":["2550 hours Training & Facilitation Experience","310 hours of Coaching Experience","Performance Management, IIM Kolkata","Master Trainer & Facilitator, Dale Carnegie","Master Coach, Erickson International","Insights Discovery Psychometric, UK","Team Management Systems, Australia","NLP Practitioner, NFNLP","Competence Developer, Carlton University","Inner Engineering, Isha Foundation","Being Centered Leader, Impossible TF","PGC HR, XLRI","Science Graduate, HNBGU"],"contact":{"mobile":"+91-9818711851","email":"praveen@talendor.in"}},{"name":"Praveen Chandola","title":"Strategic HR Consultant, Executive Coach & Trainer","slug":"praveen-chandola","description":["Praveen is a results-driven HR professional, Executive Coach & Trainer with 20+ years of strategic global experience in Human Resource and Operations.","Praveen is self-driven, nature and adventure lover, continues learning mindset person with humble attitude towards life."],"image":"/images/praveen_chandola.webp","experienceSummary":["With 20+ years of global HR experience, Praveen is passionate about people and organizational development, he has held key roles including Head HR, HR Business Partner across India, APAC, Middle East, Russia, and Latin America, and Global HR CoE Leader at Sennheiser.","Expert in building scalable processes, driving global talent strategies, and enabling cultural and organizational transformation.","Self-driven, self-aware, nature and adventure lover with continuous learning mindset and humble attitude.","Foundation Team member of India entity & build HR foundations across regions.","Led, developed & implemented global talent, leadership, and performance programs.","Driven multiple large global culture transformation and org redesign.","Successfully planned & executed complex business M&A & carve-outs.","Delivered HR digital transformation via HRIS, LMS & Intranet.","Core Global team member of DEI, wellbeing, and sustainability initiatives.","Enhanced talent acquisition, retention, and L&D impact.","Trusted partner to business leaders, aligning HR & business strategy."],"continuousLearning":["2550 hours Training & Facilitation Experience","310 hours of Coaching Experience","Performance Management, IIM Kolkata","Master Trainer & Facilitator, Dale Carnegie","Master Coach, Erickson International","Insights Discovery Psychometric, UK","Team Management Systems, Australia","NLP Practitioner, NFNLP","Competence Developer, Carlton University","Inner Engineering, Isha Foundation","Being Centered Leader, Impossible TF","PGC HR, XLRI","Science Graduate, HNBGU"],"contact":{"mobile":"+91-9818711851","email":"praveen@talendor.in"}}]});}),
"[project]/src/app/founders/[slug]/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/founders.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const FounderPage = ()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(59);
    if ($[0] !== "4a5bab0d18b48dfd1ad7f66e7d4b77e400223b2b6677c672e43c23a82d6c4098") {
        for(let $i = 0; $i < 59; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4a5bab0d18b48dfd1ad7f66e7d4b77e400223b2b6677c672e43c23a82d6c4098";
    }
    const { slug } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    let founder;
    let t0;
    let t1;
    let t10;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[1] !== slug) {
        t10 = Symbol.for("react.early_return_sentinel");
        bb0: {
            founder = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__["default"].founders.find((f)=>f.slug === slug);
            if (!founder) {
                let t11;
                if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
                    t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-20",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-4xl mx-auto px-6 text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-4xl font-bold text-gray-900 mb-4",
                                    children: "Founder Not Found"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/founders/[slug]/page.js",
                                    lineNumber: 37,
                                    columnNumber: 152
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl text-gray-600",
                                    children: "Please check the URL or select from our founders list."
                                }, void 0, false, {
                                    fileName: "[project]/src/app/founders/[slug]/page.js",
                                    lineNumber: 37,
                                    columnNumber: 228
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/founders/[slug]/page.js",
                            lineNumber: 37,
                            columnNumber: 100
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/founders/[slug]/page.js",
                        lineNumber: 37,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0));
                    $[14] = t11;
                } else {
                    t11 = $[14];
                }
                t10 = t11;
                break bb0;
            }
            t9 = "min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50";
            t7 = "max-w-6xl mx-auto px-6 py-20";
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center mt-10 mb-20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "inline-block w-32 h-32 md:w-40 md:h-40 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full shadow-2xl mb-8 overflow-hidden ring-4 ring-white/50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: founder.image,
                            alt: founder.name,
                            className: "w-full h-full object-cover"
                        }, void 0, false, {
                            fileName: "[project]/src/app/founders/[slug]/page.js",
                            lineNumber: 47,
                            columnNumber: 220
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/app/founders/[slug]/page.js",
                        lineNumber: 47,
                        columnNumber: 53
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl md:text-5xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent mb-4",
                        children: founder.name
                    }, void 0, false, {
                        fileName: "[project]/src/app/founders/[slug]/page.js",
                        lineNumber: 47,
                        columnNumber: 311
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xl md:text-2xl text-gray-700 font-semibold mb-6",
                        children: founder.title
                    }, void 0, false, {
                        fileName: "[project]/src/app/founders/[slug]/page.js",
                        lineNumber: 47,
                        columnNumber: 455
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap justify-center gap-4 text-sm md:text-base text-gray-600 max-w-2xl mx-auto",
                        children: founder.description.map(_temp)
                    }, void 0, false, {
                        fileName: "[project]/src/app/founders/[slug]/page.js",
                        lineNumber: 47,
                        columnNumber: 542
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/founders/[slug]/page.js",
                lineNumber: 47,
                columnNumber: 12
            }, ("TURBOPACK compile-time value", void 0));
            t5 = "grid md:grid-cols-2 gap-12 items-start";
            let t11;
            if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
                t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl font-bold text-gray-900 mb-6 flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-3 h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/src/app/founders/[slug]/page.js",
                            lineNumber: 51,
                            columnNumber: 93
                        }, ("TURBOPACK compile-time value", void 0)),
                        "Professional Journey"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/founders/[slug]/page.js",
                    lineNumber: 51,
                    columnNumber: 15
                }, ("TURBOPACK compile-time value", void 0));
                $[15] = t11;
            } else {
                t11 = $[15];
            }
            const t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50 sticky top-8",
                children: [
                    t11,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: founder.experienceSummary.map(_temp2)
                    }, void 0, false, {
                        fileName: "[project]/src/app/founders/[slug]/page.js",
                        lineNumber: 56,
                        columnNumber: 132
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/founders/[slug]/page.js",
                lineNumber: 56,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0));
            if ($[16] !== t12) {
                t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-8",
                    children: t12
                }, void 0, false, {
                    fileName: "[project]/src/app/founders/[slug]/page.js",
                    lineNumber: 58,
                    columnNumber: 14
                }, ("TURBOPACK compile-time value", void 0));
                $[16] = t12;
                $[17] = t6;
            } else {
                t6 = $[17];
            }
            t4 = "space-y-8";
            t2 = "bg-gradient-to-br from-emerald-500/10 to-blue-500/10 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-emerald-200/50";
            if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
                t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl font-bold text-gray-900 mb-6 flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-3 h-3 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/src/app/founders/[slug]/page.js",
                            lineNumber: 67,
                            columnNumber: 92
                        }, ("TURBOPACK compile-time value", void 0)),
                        "Continuous Learning"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/founders/[slug]/page.js",
                    lineNumber: 67,
                    columnNumber: 14
                }, ("TURBOPACK compile-time value", void 0));
                $[18] = t3;
            } else {
                t3 = $[18];
            }
            t0 = "grid grid-cols-1 md:grid-cols-2 gap-4";
            t1 = founder.continuousLearning.map(_temp3);
        }
        $[1] = slug;
        $[2] = founder;
        $[3] = t0;
        $[4] = t1;
        $[5] = t10;
        $[6] = t2;
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
        $[10] = t6;
        $[11] = t7;
        $[12] = t8;
        $[13] = t9;
    } else {
        founder = $[2];
        t0 = $[3];
        t1 = $[4];
        t10 = $[5];
        t2 = $[6];
        t3 = $[7];
        t4 = $[8];
        t5 = $[9];
        t6 = $[10];
        t7 = $[11];
        t8 = $[12];
        t9 = $[13];
    }
    if (t10 !== Symbol.for("react.early_return_sentinel")) {
        return t10;
    }
    let t11;
    if ($[19] !== t0 || $[20] !== t1) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t0,
            children: t1
        }, void 0, false, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 107,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[19] = t0;
        $[20] = t1;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] !== t11 || $[23] !== t2 || $[24] !== t3) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t2,
            children: [
                t3,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 116,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[22] = t11;
        $[23] = t2;
        $[24] = t3;
        $[25] = t12;
    } else {
        t12 = $[25];
    }
    let t13;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-2xl font-bold text-gray-900 mb-6",
            children: "Get In Touch"
        }, void 0, false, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 126,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[26] = t13;
    } else {
        t13 = $[26];
    }
    const t14 = `tel:${founder.contact.mobile}`;
    let t15;
    let t16;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "w-6 h-6 text-white",
                fill: "currentColor",
                viewBox: "0 0 20 20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"
                }, void 0, false, {
                    fileName: "[project]/src/app/founders/[slug]/page.js",
                    lineNumber: 135,
                    columnNumber: 272
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/app/founders/[slug]/page.js",
                lineNumber: 135,
                columnNumber: 196
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 135,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-gray-600",
            children: "Mobile"
        }, void 0, false, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 136,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[27] = t15;
        $[28] = t16;
    } else {
        t15 = $[27];
        t16 = $[28];
    }
    let t17;
    if ($[29] !== founder.contact.mobile) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t16,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "font-semibold text-lg text-gray-900",
                    children: founder.contact.mobile
                }, void 0, false, {
                    fileName: "[project]/src/app/founders/[slug]/page.js",
                    lineNumber: 145,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 145,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[29] = founder.contact.mobile;
        $[30] = t17;
    } else {
        t17 = $[30];
    }
    let t18;
    if ($[31] !== t14 || $[32] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: t14,
            className: "group flex items-center gap-3 p-5 bg-white/80 backdrop-blur-sm rounded-2xl border border-white/50 hover:bg-white hover:shadow-lg transition-all duration-300 hover:-translate-y-1",
            children: [
                t15,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 153,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[31] = t14;
        $[32] = t17;
        $[33] = t18;
    } else {
        t18 = $[33];
    }
    const t19 = `mailto:${founder.contact.email}`;
    let t20;
    let t21;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "w-6 h-6 text-white",
                fill: "currentColor",
                viewBox: "0 0 20 20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    d: "M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                    clipRule: "evenodd"
                }, void 0, false, {
                    fileName: "[project]/src/app/founders/[slug]/page.js",
                    lineNumber: 164,
                    columnNumber: 270
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/app/founders/[slug]/page.js",
                lineNumber: 164,
                columnNumber: 194
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 164,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-gray-600",
            children: "Email"
        }, void 0, false, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 165,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[34] = t20;
        $[35] = t21;
    } else {
        t20 = $[34];
        t21 = $[35];
    }
    let t22;
    if ($[36] !== founder.contact.email) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t21,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "font-semibold text-lg text-gray-900",
                    children: founder.contact.email
                }, void 0, false, {
                    fileName: "[project]/src/app/founders/[slug]/page.js",
                    lineNumber: 174,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 174,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[36] = founder.contact.email;
        $[37] = t22;
    } else {
        t22 = $[37];
    }
    let t23;
    if ($[38] !== t19 || $[39] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: t19,
            className: "group flex items-center gap-3 p-5 bg-white/80 backdrop-blur-sm rounded-2xl border border-white/50 hover:bg-white hover:shadow-lg transition-all duration-300 hover:-translate-y-1",
            children: [
                t20,
                t22
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 182,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[38] = t19;
        $[39] = t22;
        $[40] = t23;
    } else {
        t23 = $[40];
    }
    let t24;
    if ($[41] !== t18 || $[42] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-gradient-to-r from-purple-500/10 to-pink-500/10 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-purple-200/50",
            children: [
                t13,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4",
                    children: [
                        t18,
                        t23
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/founders/[slug]/page.js",
                    lineNumber: 191,
                    columnNumber: 155
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 191,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[41] = t18;
        $[42] = t23;
        $[43] = t24;
    } else {
        t24 = $[43];
    }
    let t25;
    if ($[44] !== t12 || $[45] !== t24 || $[46] !== t4) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t4,
            children: [
                t12,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 200,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[44] = t12;
        $[45] = t24;
        $[46] = t4;
        $[47] = t25;
    } else {
        t25 = $[47];
    }
    let t26;
    if ($[48] !== t25 || $[49] !== t5 || $[50] !== t6) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t5,
            children: [
                t6,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 210,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[48] = t25;
        $[49] = t5;
        $[50] = t6;
        $[51] = t26;
    } else {
        t26 = $[51];
    }
    let t27;
    if ($[52] !== t26 || $[53] !== t7 || $[54] !== t8) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t7,
            children: [
                t8,
                t26
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 220,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[52] = t26;
        $[53] = t7;
        $[54] = t8;
        $[55] = t27;
    } else {
        t27 = $[55];
    }
    let t28;
    if ($[56] !== t27 || $[57] !== t9) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t9,
            children: t27
        }, void 0, false, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 230,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[56] = t27;
        $[57] = t9;
        $[58] = t28;
    } else {
        t28 = $[58];
    }
    return t28;
};
_s(FounderPage, "xBgltSYF7fXJ7A9Ofx6yfOn4wn4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = FounderPage;
const __TURBOPACK__default__export__ = FounderPage;
function _temp(desc, index) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: "bg-white/70 backdrop-blur-sm px-6 py-3 rounded-2xl shadow-lg border border-white/50",
        children: desc
    }, index, false, {
        fileName: "[project]/src/app/founders/[slug]/page.js",
        lineNumber: 241,
        columnNumber: 10
    }, this);
}
function _temp2(item, index_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "group flex items-start gap-4 p-4 hover:bg-blue-50 rounded-2xl transition-all duration-300 hover:scale-[1.02] hover:shadow-md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-all duration-300"
            }, void 0, false, {
                fileName: "[project]/src/app/founders/[slug]/page.js",
                lineNumber: 244,
                columnNumber: 166
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-700 leading-relaxed",
                children: item
            }, void 0, false, {
                fileName: "[project]/src/app/founders/[slug]/page.js",
                lineNumber: 244,
                columnNumber: 299
            }, this)
        ]
    }, index_0, true, {
        fileName: "[project]/src/app/founders/[slug]/page.js",
        lineNumber: 244,
        columnNumber: 10
    }, this);
}
function _temp3(item_0, index_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "group bg-white/60 backdrop-blur-sm p-5 rounded-2xl border border-white/50 hover:bg-white hover:shadow-lg transition-all duration-300 hover:-translate-y-1",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "font-semibold text-gray-800 group-hover:text-emerald-700",
            children: item_0
        }, void 0, false, {
            fileName: "[project]/src/app/founders/[slug]/page.js",
            lineNumber: 247,
            columnNumber: 195
        }, this)
    }, index_1, false, {
        fileName: "[project]/src/app/founders/[slug]/page.js",
        lineNumber: 247,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "FounderPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_6f4c83ec._.js.map