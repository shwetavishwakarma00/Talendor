(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/data/products.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"products":[{"slug":"insights-discovery","hero":{"badge":"Our flagship product","title":"Insights Discovery: four colours, powerful self-awareness","description":"A simple four-colour model that helps people understand themselves, appreciate others, and unlock better collaboration at work.","image":{"src":"/images/talendorp1.png","alt":"Insights Discovery four-colour wheel"}},"fourColourModel":{"title":"The four-colour model","description":"Every person has a unique mix of Fiery Red, Sunshine Yellow, Earth Green and Cool Blue energies, shaping how they think, decide and communicate at work.","items":[{"title":"Fiery Red","desc":"Competitive, determined and purposeful; brings drive, focus and action.","color":"from-red-500 to-orange-400"},{"title":"Sunshine Yellow","desc":"Sociable, enthusiastic and persuasive; energises others and builds relationships.","color":"from-amber-400 to-orange-500"},{"title":"Earth Green","desc":"Caring, encouraging and patient; creates stability, support and trust.","color":"from-emerald-500 to-lime-400"},{"title":"Cool Blue","desc":"Cautious, precise and questioning; adds structure, quality and clarity.","color":"from-sky-500 to-blue-700"}]},"journey":{"title":"Where can Insights Discovery take you?","description":"Use Insights Discovery as the foundation for leadership, team development and culture change, building a shared language that turns awareness into everyday behaviour.","areas":["Leadership development","Team effectiveness","Change and resilience","Engagement and culture","Sales, consulting & service","Coaching and mentoring"],"image":{"src":"/images/talendorp1.png","alt":"Insights Discovery journey wheel"}},"expertise":{"badge":"Our areas of expertise","title":"Turning insight into everyday performance","description":"Programmes focus on the skills organisations need most, from trust and feedback to stakeholder management and inclusive leadership.","tags":["Coaching & mentoring","Team engagement","Improving performance","Trust and psychological safety","Developing potential","Managing stakeholders","Effective communication","Feedback that lands","Empathy and inclusion","Inspiring others"]},"connectingTeams":{"title":"Connecting teams across your organisation","description":"Workshops help people break down silos, communicate with clarity, and collaborate around shared goals using a common colour language.","points":["Highly interactive, facilitator-led experiences.","Practical tools that transfer back into day-to-day work.","Action plans that sustain behaviour change over time."],"card":{"badge":"Self-aware teams","text":"When people understand themselves and each other, they build stronger relationships, handle conflict constructively, and deliver better results together.","cta":"Book a discovery session"}},"cta":{"title":"Ready to start your Insights Discovery journey?","description":"Partner with our certified practitioners to design a programme that grows self-awareness, trust and performance across your teams.","primary":"Schedule a call","secondary":"Download overview"}}]});}),
"[project]/src/app/products/[slug]/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/products.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const fadeUp = {
    hidden: {
        opacity: 0,
        y: 30
    },
    visible: (i)=>({
            opacity: 1,
            y: 0,
            transition: {
                delay: 0.1 * i,
                duration: 0.5,
                ease: "easeOut"
            }
        })
};
function ProductPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(55);
    if ($[0] !== "994ee8048f02f9c2adf4b0857fd3c99de2583d8eaa7b16afb8f5d9248214513e") {
        for(let $i = 0; $i < 55; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "994ee8048f02f9c2adf4b0857fd3c99de2583d8eaa7b16afb8f5d9248214513e";
    }
    const { slug } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    let product;
    let t0;
    let t1;
    let t10;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[1] !== slug) {
        t10 = Symbol.for("react.early_return_sentinel");
        bb0: {
            product = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$json__$28$json$29$__["default"].products.find({
                "ProductPage[productsData.products.find()]": (p)=>p.slug === slug
            }["ProductPage[productsData.products.find()]"]);
            if (!product) {
                let t11;
                if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
                    t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-10",
                        children: "Product not found"
                    }, void 0, false, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 55,
                        columnNumber: 17
                    }, this);
                    $[14] = t11;
                } else {
                    t11 = $[14];
                }
                t10 = t11;
                break bb0;
            }
            t6 = "min-h-screen bg-white text-slate-900";
            let t11;
            let t12;
            let t13;
            if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
                t11 = {
                    opacity: 0,
                    y: 30
                };
                t12 = {
                    opacity: 1,
                    y: 0
                };
                t13 = {
                    duration: 0.6
                };
                $[15] = t11;
                $[16] = t12;
                $[17] = t13;
            } else {
                t11 = $[15];
                t12 = $[16];
                t13 = $[17];
            }
            const t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: t11,
                animate: t12,
                transition: t13,
                className: "max-w-3xl mx-auto text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs uppercase tracking-widest mb-2 text-purple-100",
                        children: product.hero.badge
                    }, void 0, false, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 87,
                        columnNumber: 118
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-3xl md:text-5xl font-bold mb-4 leading-tight",
                        children: product.hero.title
                    }, void 0, false, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 87,
                        columnNumber: 212
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-lg text-purple-100/80 mb-6",
                        children: product.hero.description
                    }, void 0, false, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 87,
                        columnNumber: 303
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 87,
                columnNumber: 19
            }, this);
            if ($[18] !== t14) {
                t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "relative bg-gradient-to-r from-purple-600 to-indigo-700 text-white py-20 my-5 px-6",
                    children: t14
                }, void 0, false, {
                    fileName: "[project]/src/app/products/[slug]/page.js",
                    lineNumber: 89,
                    columnNumber: 14
                }, this);
                $[18] = t14;
                $[19] = t7;
            } else {
                t7 = $[19];
            }
            let t15;
            if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
                t15 = {
                    once: true
                };
                $[20] = t15;
            } else {
                t15 = $[20];
            }
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "mx-auto max-w-6xl px-6 py-16",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "text-center",
                        initial: "hidden",
                        whileInView: "visible",
                        viewport: t15,
                        custom: 0,
                        variants: fadeUp,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-semibold",
                                children: product.fourColourModel.title
                            }, void 0, false, {
                                fileName: "[project]/src/app/products/[slug]/page.js",
                                lineNumber: 104,
                                columnNumber: 181
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-3 text-slate-600",
                                children: product.fourColourModel.description
                            }, void 0, false, {
                                fileName: "[project]/src/app/products/[slug]/page.js",
                                lineNumber: 104,
                                columnNumber: 256
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 104,
                        columnNumber: 62
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4",
                        children: product.fourColourModel.items.map(_ProductPageProductFourColourModelItemsMap)
                    }, void 0, false, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 104,
                        columnNumber: 345
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 104,
                columnNumber: 12
            }, this);
            const t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-semibold",
                        children: product.journey.title
                    }, void 0, false, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 105,
                        columnNumber: 24
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-3 text-slate-600",
                        children: product.journey.description
                    }, void 0, false, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 105,
                        columnNumber: 91
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-6 grid sm:grid-cols-2 gap-4",
                        children: product.journey.areas.map(_ProductPageProductJourneyAreasMap)
                    }, void 0, false, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 105,
                        columnNumber: 159
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 105,
                columnNumber: 19
            }, this);
            const t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative h-64 w-64 mx-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: product.journey.image.src,
                    alt: product.journey.image.alt,
                    fill: true,
                    className: "object-contain"
                }, void 0, false, {
                    fileName: "[project]/src/app/products/[slug]/page.js",
                    lineNumber: 106,
                    columnNumber: 63
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 106,
                columnNumber: 19
            }, this);
            if ($[21] !== t16 || $[22] !== t17) {
                t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "bg-slate-50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mx-auto max-w-6xl px-6 py-16 grid md:grid-cols-2 gap-10",
                        children: [
                            t16,
                            t17
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/products/[slug]/page.js",
                        lineNumber: 108,
                        columnNumber: 47
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/products/[slug]/page.js",
                    lineNumber: 108,
                    columnNumber: 14
                }, this);
                $[21] = t16;
                $[22] = t17;
                $[23] = t9;
            } else {
                t9 = $[23];
            }
            t2 = "mx-auto max-w-6xl px-6 py-16 text-center";
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs uppercase tracking-widest text-purple-600",
                children: product.expertise.badge
            }, void 0, false, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 116,
                columnNumber: 12
            }, this);
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "mt-2 text-2xl font-semibold",
                children: product.expertise.title
            }, void 0, false, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 117,
                columnNumber: 12
            }, this);
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-3 text-slate-600",
                children: product.expertise.description
            }, void 0, false, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 118,
                columnNumber: 12
            }, this);
            t0 = "mt-8 flex flex-wrap justify-center gap-3";
            t1 = product.expertise.tags.map(_ProductPageProductExpertiseTagsMap);
        }
        $[1] = slug;
        $[2] = product;
        $[3] = t0;
        $[4] = t1;
        $[5] = t10;
        $[6] = t2;
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
        $[10] = t6;
        $[11] = t7;
        $[12] = t8;
        $[13] = t9;
    } else {
        product = $[2];
        t0 = $[3];
        t1 = $[4];
        t10 = $[5];
        t2 = $[6];
        t3 = $[7];
        t4 = $[8];
        t5 = $[9];
        t6 = $[10];
        t7 = $[11];
        t8 = $[12];
        t9 = $[13];
    }
    if (t10 !== Symbol.for("react.early_return_sentinel")) {
        return t10;
    }
    let t11;
    if ($[24] !== t0 || $[25] !== t1) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t0,
            children: t1
        }, void 0, false, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 154,
            columnNumber: 11
        }, this);
        $[24] = t0;
        $[25] = t1;
        $[26] = t11;
    } else {
        t11 = $[26];
    }
    let t12;
    if ($[27] !== t11 || $[28] !== t2 || $[29] !== t3 || $[30] !== t4 || $[31] !== t5) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t2,
            children: [
                t3,
                t4,
                t5,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 163,
            columnNumber: 11
        }, this);
        $[27] = t11;
        $[28] = t2;
        $[29] = t3;
        $[30] = t4;
        $[31] = t5;
        $[32] = t12;
    } else {
        t12 = $[32];
    }
    let t13;
    if ($[33] !== product.cta.title) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-2xl font-semibold",
            children: product.cta.title
        }, void 0, false, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 175,
            columnNumber: 11
        }, this);
        $[33] = product.cta.title;
        $[34] = t13;
    } else {
        t13 = $[34];
    }
    let t14;
    if ($[35] !== product.cta.description) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mt-3",
            children: product.cta.description
        }, void 0, false, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 183,
            columnNumber: 11
        }, this);
        $[35] = product.cta.description;
        $[36] = t14;
    } else {
        t14 = $[36];
    }
    let t15;
    if ($[37] !== product.cta.primary) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "bg-white text-purple-700 px-6 py-2 rounded-full",
            children: product.cta.primary
        }, void 0, false, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 191,
            columnNumber: 11
        }, this);
        $[37] = product.cta.primary;
        $[38] = t15;
    } else {
        t15 = $[38];
    }
    let t16;
    if ($[39] !== product.cta.secondary) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "border border-white px-6 py-2 rounded-full",
            children: product.cta.secondary
        }, void 0, false, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 199,
            columnNumber: 11
        }, this);
        $[39] = product.cta.secondary;
        $[40] = t16;
    } else {
        t16 = $[40];
    }
    let t17;
    if ($[41] !== t15 || $[42] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-6 flex justify-center gap-3",
            children: [
                t15,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 207,
            columnNumber: 11
        }, this);
        $[41] = t15;
        $[42] = t16;
        $[43] = t17;
    } else {
        t17 = $[43];
    }
    let t18;
    if ($[44] !== t13 || $[45] !== t14 || $[46] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "mx-auto max-w-6xl px-6 py-14",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-3xl bg-gradient-to-r from-purple-600 to-indigo-700 text-center text-white p-10",
                children: [
                    t13,
                    t14,
                    t17
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 216,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 216,
            columnNumber: 11
        }, this);
        $[44] = t13;
        $[45] = t14;
        $[46] = t17;
        $[47] = t18;
    } else {
        t18 = $[47];
    }
    let t19;
    if ($[48] !== t12 || $[49] !== t18 || $[50] !== t6 || $[51] !== t7 || $[52] !== t8 || $[53] !== t9) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: t6,
            children: [
                t7,
                t8,
                t9,
                t12,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/products/[slug]/page.js",
            lineNumber: 226,
            columnNumber: 11
        }, this);
        $[48] = t12;
        $[49] = t18;
        $[50] = t6;
        $[51] = t7;
        $[52] = t8;
        $[53] = t9;
        $[54] = t19;
    } else {
        t19 = $[54];
    }
    return t19;
}
_s(ProductPage, "xBgltSYF7fXJ7A9Ofx6yfOn4wn4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = ProductPage;
function _ProductPageProductExpertiseTagsMap(tag, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].span, {
        initial: "hidden",
        whileInView: "visible",
        viewport: {
            once: true
        },
        custom: i + 1,
        variants: fadeUp,
        className: "rounded-full bg-slate-100 px-4 py-2 text-sm",
        children: tag
    }, tag, false, {
        fileName: "[project]/src/app/products/[slug]/page.js",
        lineNumber: 240,
        columnNumber: 10
    }, this);
}
function _ProductPageProductJourneyAreasMap(area) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white p-3 rounded-xl shadow-sm",
        children: area
    }, area, false, {
        fileName: "[project]/src/app/products/[slug]/page.js",
        lineNumber: 245,
        columnNumber: 10
    }, this);
}
function _ProductPageProductFourColourModelItemsMap(item, idx) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].article, {
        className: "rounded-2xl border p-5",
        initial: "hidden",
        whileInView: "visible",
        viewport: {
            once: true
        },
        custom: idx + 1,
        variants: fadeUp,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `h-1 w-full rounded-full bg-gradient-to-r ${item.color}`
            }, void 0, false, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 250,
                columnNumber: 41
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "mt-3 font-semibold",
                children: item.title
            }, void 0, false, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 250,
                columnNumber: 117
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2 text-sm text-slate-600",
                children: item.desc
            }, void 0, false, {
                fileName: "[project]/src/app/products/[slug]/page.js",
                lineNumber: 250,
                columnNumber: 169
            }, this)
        ]
    }, item.title, true, {
        fileName: "[project]/src/app/products/[slug]/page.js",
        lineNumber: 248,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "ProductPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_d9738a92._.js.map