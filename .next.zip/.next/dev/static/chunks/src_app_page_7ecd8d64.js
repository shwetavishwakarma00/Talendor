(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_60284ba6._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_fdd5ade6._.js",
  "static/chunks/node_modules_react-icons_io_index_mjs_7f31b177._.js",
  "static/chunks/node_modules_react-icons_gi_index_mjs_657583d5._.js",
  "static/chunks/node_modules_react-icons_ai_index_mjs_9504e8ee._.js",
  "static/chunks/node_modules_react-icons_hi_index_mjs_c1b692d7._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_150b4c77._.js",
  "static/chunks/node_modules_2276d326._.js"
],
    source: "dynamic"
});
