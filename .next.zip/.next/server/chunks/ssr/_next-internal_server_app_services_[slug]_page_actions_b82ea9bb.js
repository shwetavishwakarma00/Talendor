module.exports=[38595,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_%5Bslug%5D_page_actions_b82ea9bb.js.map