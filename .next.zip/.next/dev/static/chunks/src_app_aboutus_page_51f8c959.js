(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f6c9c943._.js",
  "static/chunks/src_app_aboutus_page_013b2bba.js"
],
    source: "dynamic"
});
