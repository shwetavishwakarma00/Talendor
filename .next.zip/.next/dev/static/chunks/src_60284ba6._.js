(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/data/products.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"products":[{"slug":"insights-discovery","hero":{"badge":"Our flagship product","title":"Insights Discovery: four colours, powerful self-awareness","description":"A simple four-colour model that helps people understand themselves, appreciate others, and unlock better collaboration at work.","image":{"src":"/images/talendorp1.png","alt":"Insights Discovery four-colour wheel"}},"fourColourModel":{"title":"The four-colour model","description":"Every person has a unique mix of Fiery Red, Sunshine Yellow, Earth Green and Cool Blue energies, shaping how they think, decide and communicate at work.","items":[{"title":"Fiery Red","desc":"Competitive, determined and purposeful; brings drive, focus and action.","color":"from-red-500 to-orange-400"},{"title":"Sunshine Yellow","desc":"Sociable, enthusiastic and persuasive; energises others and builds relationships.","color":"from-amber-400 to-orange-500"},{"title":"Earth Green","desc":"Caring, encouraging and patient; creates stability, support and trust.","color":"from-emerald-500 to-lime-400"},{"title":"Cool Blue","desc":"Cautious, precise and questioning; adds structure, quality and clarity.","color":"from-sky-500 to-blue-700"}]},"journey":{"title":"Where can Insights Discovery take you?","description":"Use Insights Discovery as the foundation for leadership, team development and culture change, building a shared language that turns awareness into everyday behaviour.","areas":["Leadership development","Team effectiveness","Change and resilience","Engagement and culture","Sales, consulting & service","Coaching and mentoring"],"image":{"src":"/images/talendorp1.png","alt":"Insights Discovery journey wheel"}},"expertise":{"badge":"Our areas of expertise","title":"Turning insight into everyday performance","description":"Programmes focus on the skills organisations need most, from trust and feedback to stakeholder management and inclusive leadership.","tags":["Coaching & mentoring","Team engagement","Improving performance","Trust and psychological safety","Developing potential","Managing stakeholders","Effective communication","Feedback that lands","Empathy and inclusion","Inspiring others"]},"connectingTeams":{"title":"Connecting teams across your organisation","description":"Workshops help people break down silos, communicate with clarity, and collaborate around shared goals using a common colour language.","points":["Highly interactive, facilitator-led experiences.","Practical tools that transfer back into day-to-day work.","Action plans that sustain behaviour change over time."],"card":{"badge":"Self-aware teams","text":"When people understand themselves and each other, they build stronger relationships, handle conflict constructively, and deliver better results together.","cta":"Book a discovery session"}},"cta":{"title":"Ready to start your Insights Discovery journey?","description":"Partner with our certified practitioners to design a programme that grows self-awareness, trust and performance across your teams.","primary":"Schedule a call","secondary":"Download overview"}}]});}),
"[project]/src/components/HeroSection.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/products.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function HeroSection() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(35);
    if ($[0] !== "7fc41eaf382e2c2c086a9a09a5935cd372039ecf39c9bb3b93cd5a5dd31bf163") {
        for(let $i = 0; $i < 35; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7fc41eaf382e2c2c086a9a09a5935cd372039ecf39c9bb3b93cd5a5dd31bf163";
    }
    const product = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$json__$28$json$29$__["default"].products[0];
    const slug = product.slug;
    let t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "absolute -top-10 -right-32 w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply opacity-30 blur-3xl animate-blob"
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 23,
            columnNumber: 10
        }, this);
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "absolute -bottom-32 -right-32 w-96 h-96 bg-orange-300 rounded-full mix-blend-multiply opacity-30 blur-3xl animate-blob animation-delay-2000"
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 24,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "absolute top-10 -left-32 w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply opacity-30 blur-3xl animate-blob"
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 25,
            columnNumber: 10
        }, this);
        $[1] = t0;
        $[2] = t1;
        $[3] = t2;
    } else {
        t0 = $[1];
        t1 = $[2];
        t2 = $[3];
    }
    let t3;
    let t4;
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            opacity: 0,
            y: 50
        };
        t4 = {
            opacity: 1,
            y: 0
        };
        t5 = {
            duration: 0.9,
            ease: "easeOut"
        };
        $[4] = t3;
        $[5] = t4;
        $[6] = t5;
    } else {
        t3 = $[4];
        t4 = $[5];
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
            className: "text-sm text-gray-500 mb-2",
            initial: {
                opacity: 0,
                y: 20
            },
            animate: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: 0.2
            },
            children: "HR EXCELLENCE REDEFINED"
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 60,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    let t8;
    let t9;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            opacity: 0,
            y: 20
        };
        t8 = {
            opacity: 1,
            y: 0
        };
        t9 = {
            delay: 0.3
        };
        $[8] = t7;
        $[9] = t8;
        $[10] = t9;
    } else {
        t7 = $[8];
        t8 = $[9];
        t9 = $[10];
    }
    let t10;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h1, {
            className: "text-4xl lg:text-5xl font-bold text-black font-heading",
            initial: t7,
            animate: t8,
            transition: t9,
            children: [
                "WELCOME TO",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "block font-heading text-5xl font-extrabold bg-gradient-to-r from-purple-800 to-orange-400 bg-clip-text text-transparent",
                    children: "TALENDOR"
                }, void 0, false, {
                    fileName: "[project]/src/components/HeroSection.jsx",
                    lineNumber: 98,
                    columnNumber: 141
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 98,
            columnNumber: 11
        }, this);
        $[11] = t10;
    } else {
        t10 = $[11];
    }
    let t11;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
            className: "text-lg  text-gray-600 mt-4",
            initial: {
                opacity: 0,
                y: 20
            },
            animate: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: 0.4
            },
            children: "Door to all your Talent Needs"
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 105,
            columnNumber: 11
        }, this);
        $[12] = t11;
    } else {
        t11 = $[12];
    }
    let t12;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
            className: "text-gray-500 font-para mt-6 max-w-xl mx-auto lg:mx-0",
            initial: {
                opacity: 0,
                y: 20
            },
            animate: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: 0.5
            },
            children: "At Talendor, we don’t just connect businesses with talent; we create lasting partnerships that drive growth, innovation, and excellence."
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 120,
            columnNumber: 11
        }, this);
        $[13] = t12;
    } else {
        t12 = $[13];
    }
    let t13;
    let t14;
    let t15;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            opacity: 0,
            y: 15
        };
        t14 = {
            opacity: 1,
            y: 0
        };
        t15 = {
            delay: 0.7,
            duration: 0.6
        };
        $[14] = t13;
        $[15] = t14;
        $[16] = t15;
    } else {
        t13 = $[14];
        t14 = $[15];
        t15 = $[16];
    }
    let t16;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "flex-1 flex flex-col justify-start lg:justify-center items-center lg:items-start text-center lg:text-left min-h-[420px] pt-6 lg:pt-0",
            initial: t3,
            animate: t4,
            transition: t5,
            children: [
                t6,
                t10,
                t11,
                t12,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "mt-10 flex justify-center lg:justify-start",
                    initial: t13,
                    animate: t14,
                    transition: t15,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: `/products/${slug}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "px-7 py-3 bg-[#5454AB] text-white rounded-full font-medium hover:bg-[#43438f] hover:scale-105 transition",
                            children: "Explore Now"
                        }, void 0, false, {
                            fileName: "[project]/src/components/HeroSection.jsx",
                            lineNumber: 159,
                            columnNumber: 374
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeroSection.jsx",
                        lineNumber: 159,
                        columnNumber: 341
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/HeroSection.jsx",
                    lineNumber: 159,
                    columnNumber: 229
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 159,
            columnNumber: 11
        }, this);
        $[17] = t16;
    } else {
        t16 = $[17];
    }
    let t17;
    let t18;
    let t19;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = {
            opacity: 0
        };
        t18 = {
            y: [
                0,
                -10,
                0
            ],
            opacity: [
                0.8,
                1,
                0.8
            ]
        };
        t19 = {
            duration: 4,
            repeat: Infinity,
            repeatType: "mirror"
        };
        $[18] = t17;
        $[19] = t18;
        $[20] = t19;
    } else {
        t17 = $[18];
        t18 = $[19];
        t19 = $[20];
    }
    let t20;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                id: "waveGrad1",
                x1: "0%",
                x2: "100%",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                        offset: "0%",
                        stopColor: "#E19D36",
                        stopOpacity: "0.1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeroSection.jsx",
                        lineNumber: 190,
                        columnNumber: 66
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                        offset: "50%",
                        stopColor: "#E19D36",
                        stopOpacity: "0.4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeroSection.jsx",
                        lineNumber: 190,
                        columnNumber: 124
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                        offset: "100%",
                        stopColor: "#E19D36",
                        stopOpacity: "0.1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeroSection.jsx",
                        lineNumber: 190,
                        columnNumber: 183
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/HeroSection.jsx",
                lineNumber: 190,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 190,
            columnNumber: 11
        }, this);
        $[21] = t20;
    } else {
        t20 = $[21];
    }
    let t21;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].svg, {
            className: "absolute top-[40%] md:top-30 left-1/2 w-[95%] -translate-x-1/2 z-20",
            viewBox: "0 0 400 120",
            fill: "none",
            initial: t17,
            animate: t18,
            transition: t19,
            children: [
                t20,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].path, {
                    d: "M0 60 C100 120 300 0 400 60",
                    stroke: "url(#waveGrad1)",
                    strokeWidth: "3",
                    strokeLinecap: "round",
                    initial: {
                        pathLength: 0
                    },
                    animate: {
                        pathLength: 1
                    },
                    transition: {
                        duration: 1.2,
                        delay: 1,
                        ease: "easeInOut"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/HeroSection.jsx",
                    lineNumber: 197,
                    columnNumber: 187
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 197,
            columnNumber: 11
        }, this);
        $[22] = t21;
    } else {
        t21 = $[22];
    }
    let t22;
    let t23;
    let t24;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = {
            opacity: 0
        };
        t23 = {
            y: [
                0,
                8,
                0
            ],
            opacity: [
                0.7,
                1,
                0.7
            ]
        };
        t24 = {
            duration: 5,
            repeat: Infinity,
            repeatType: "mirror"
        };
        $[23] = t22;
        $[24] = t23;
        $[25] = t24;
    } else {
        t22 = $[23];
        t23 = $[24];
        t24 = $[25];
    }
    let t25;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                id: "waveGrad2",
                x1: "0%",
                x2: "100%",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                        offset: "0%",
                        stopColor: "#E19D36",
                        stopOpacity: "0.1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeroSection.jsx",
                        lineNumber: 236,
                        columnNumber: 66
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                        offset: "50%",
                        stopColor: "#E19D36",
                        stopOpacity: "0.5"
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeroSection.jsx",
                        lineNumber: 236,
                        columnNumber: 124
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                        offset: "100%",
                        stopColor: "#E19D36",
                        stopOpacity: "0.1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeroSection.jsx",
                        lineNumber: 236,
                        columnNumber: 183
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/HeroSection.jsx",
                lineNumber: 236,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 236,
            columnNumber: 11
        }, this);
        $[26] = t25;
    } else {
        t25 = $[26];
    }
    let t26;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].svg, {
            className: "absolute top-[50%] md:top-50 left-1/2 w-[105%] -translate-x-1/2 z-20",
            viewBox: "0 0 450 120",
            fill: "none",
            initial: t22,
            animate: t23,
            transition: t24,
            children: [
                t25,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].path, {
                    d: "M0 50 C150 110 300 -10 450 50",
                    stroke: "url(#waveGrad2)",
                    strokeWidth: "2.5",
                    strokeLinecap: "round",
                    initial: {
                        pathLength: 0
                    },
                    animate: {
                        pathLength: 1
                    },
                    transition: {
                        duration: 1.2,
                        delay: 1.2,
                        ease: "easeInOut"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/HeroSection.jsx",
                    lineNumber: 243,
                    columnNumber: 188
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 243,
            columnNumber: 11
        }, this);
        $[27] = t26;
    } else {
        t26 = $[27];
    }
    let t27;
    let t28;
    let t29;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = {
            scale: 0
        };
        t28 = {
            scale: 1
        };
        t29 = {
            duration: 1
        };
        $[28] = t27;
        $[29] = t28;
        $[30] = t29;
    } else {
        t27 = $[28];
        t28 = $[29];
        t29 = $[30];
    }
    let t30;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 relative flex justify-center -mt-10 sm:mt-6 lg:mt-0",
            children: [
                t21,
                t26,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "\r\n  relative\r\n w-[82vw] sm:w-[70vw] max-w-[480px]\r\n  aspect-square\r\n  mx-auto\r\n  rounded-full\r\n  border-dotted border-[4px] border-[#96b4d5]\r\n  flex items-center justify-center\r\n  z-10\r\n",
                    initial: t27,
                    animate: t28,
                    transition: t29,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "\r\n    w-[85%]\r\n    aspect-square\r\n    rounded-full\r\n    overflow-hidden\r\n    relative\r\n  ",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/images/herosectionimg.jpg",
                            alt: "Team Collaboration",
                            fill: true,
                            className: "object-cover"
                        }, void 0, false, {
                            fileName: "[project]/src/components/HeroSection.jsx",
                            lineNumber: 279,
                            columnNumber: 494
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeroSection.jsx",
                        lineNumber: 279,
                        columnNumber: 373
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/HeroSection.jsx",
                    lineNumber: 279,
                    columnNumber: 97
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 279,
            columnNumber: 11
        }, this);
        $[31] = t30;
    } else {
        t30 = $[31];
    }
    let t31;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "absolute top-40 left-230 p-3 bg-white rounded-full shadow-lg hidden md:block",
            animate: {
                y: [
                    0,
                    -10,
                    0
                ]
            },
            transition: {
                duration: 2,
                repeat: Infinity
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaUsers"], {
                className: "text-purple-500 w-6 h-6"
            }, void 0, false, {
                fileName: "[project]/src/components/HeroSection.jsx",
                lineNumber: 291,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 286,
            columnNumber: 11
        }, this);
        $[32] = t31;
    } else {
        t31 = $[32];
    }
    let t32;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "absolute top-24 right-40 p-3 bg-white rounded-full shadow-lg hidden md:block",
            animate: {
                y: [
                    0,
                    10,
                    0
                ]
            },
            transition: {
                duration: 2.5,
                repeat: Infinity
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaLightbulb"], {
                className: "text-yellow-400 w-6 h-6"
            }, void 0, false, {
                fileName: "[project]/src/components/HeroSection.jsx",
                lineNumber: 303,
                columnNumber: 8
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 298,
            columnNumber: 11
        }, this);
        $[33] = t32;
    } else {
        t32 = $[33];
    }
    let t33;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "jsx-68693b4754ae57b" + " " + "w-full min-h-[600px] relative overflow-hidden mt-20 pt-16 pb-20 bg-gradient-to-b from-white to-gray-50",
            children: [
                t0,
                t1,
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "jsx-68693b4754ae57b" + " " + "container mx-auto px-6 lg:px-20 flex flex-col lg:flex-row items-center justify-center lg:justify-between gap-10 min-h-[600px]",
                    children: [
                        t16,
                        t30,
                        t31,
                        t32,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            className: "absolute bottom-44 right-56 p-3 bg-white rounded-full shadow-lg hidden md:block",
                            animate: {
                                y: [
                                    0,
                                    -15,
                                    0
                                ]
                            },
                            transition: {
                                duration: 3,
                                repeat: Infinity
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaChartLine"], {
                                className: "text-orange-500 w-6 h-6"
                            }, void 0, false, {
                                fileName: "[project]/src/components/HeroSection.jsx",
                                lineNumber: 315,
                                columnNumber: 12
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/HeroSection.jsx",
                            lineNumber: 310,
                            columnNumber: 310
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/HeroSection.jsx",
                    lineNumber: 310,
                    columnNumber: 147
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    id: "68693b4754ae57b",
                    children: ".animate-blob.jsx-68693b4754ae57b{animation:7s infinite blob}.animation-delay-2000.jsx-68693b4754ae57b{animation-delay:2s}@keyframes blob{0%{transform:translate(0)scale(1)}33%{transform:translate(30px,-50px)scale(1.1)}66%{transform:translate(-20px,20px)scale(.9)}to{transform:translate(0)scale(1)}}"
                }, void 0, false, void 0, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/HeroSection.jsx",
            lineNumber: 310,
            columnNumber: 11
        }, this);
        $[34] = t33;
    } else {
        t33 = $[34];
    }
    return t33;
}
_c = HeroSection;
var _c;
__turbopack_context__.k.register(_c, "HeroSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ExpertiseSection.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ExpertiseSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/gi/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
function ExpertiseSection() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "74735edb72c9530ecc75a8fdce534f9e57177af4061dc96e7808ffc96dfddec1") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "74735edb72c9530ecc75a8fdce534f9e57177af4061dc96e7808ffc96dfddec1";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "text-center max-w-2xl mx-auto px-4",
            initial: {
                opacity: 0,
                y: -20
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                duration: 0.6
            },
            viewport: {
                once: true
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-2xl font-heading sm:text-2xl font-bold text-black",
                    children: "OUR EXPERTISE"
                }, void 0, false, {
                    fileName: "[project]/src/components/ExpertiseSection.jsx",
                    lineNumber: 28,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm font-para sm:text-base text-gray-600 mt-2 sm:mt-3",
                    children: "Customized to your business needs"
                }, void 0, false, {
                    fileName: "[project]/src/components/ExpertiseSection.jsx",
                    lineNumber: 28,
                    columnNumber: 97
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ExpertiseSection.jsx",
            lineNumber: 18,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpertiseCard, {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaHorseHead"], {}, void 0, false, {
                fileName: "[project]/src/components/ExpertiseSection.jsx",
                lineNumber: 35,
                columnNumber: 31
            }, void 0),
            title: "Strategic HR Consulting"
        }, void 0, false, {
            fileName: "[project]/src/components/ExpertiseSection.jsx",
            lineNumber: 35,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpertiseCard, {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoIosSearch"], {}, void 0, false, {
                fileName: "[project]/src/components/ExpertiseSection.jsx",
                lineNumber: 42,
                columnNumber: 31
            }, void 0),
            title: "Executive Search"
        }, void 0, false, {
            fileName: "[project]/src/components/ExpertiseSection.jsx",
            lineNumber: 42,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpertiseCard, {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaRocket"], {}, void 0, false, {
                fileName: "[project]/src/components/ExpertiseSection.jsx",
                lineNumber: 49,
                columnNumber: 31
            }, void 0),
            title: "Leadership Development"
        }, void 0, false, {
            fileName: "[project]/src/components/ExpertiseSection.jsx",
            lineNumber: 49,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "\r\n        w-full\r\n        py-14 sm:py-16 md:py-20\r\n        min-h-[420px] md:h-[480px]\r\n        bg-gradient-to-b\r\n        from-[#5454AB]/10\r\n        to-[#5454AB]/5\r\n      ",
            children: [
                t0,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 sm:px-6 mt-10 sm:mt-12 md:mt-14 grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 md:gap-10",
                    children: [
                        t1,
                        t2,
                        t3,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ExpertiseCard, {
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GiTeamIdea"], {}, void 0, false, {
                                fileName: "[project]/src/components/ExpertiseSection.jsx",
                                lineNumber: 56,
                                columnNumber: 384
                            }, void 0),
                            title: "Team Development"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ExpertiseSection.jsx",
                            lineNumber: 56,
                            columnNumber: 363
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ExpertiseSection.jsx",
                    lineNumber: 56,
                    columnNumber: 222
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ExpertiseSection.jsx",
            lineNumber: 56,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    return t4;
}
_c = ExpertiseSection;
function ExpertiseCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "74735edb72c9530ecc75a8fdce534f9e57177af4061dc96e7808ffc96dfddec1") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "74735edb72c9530ecc75a8fdce534f9e57177af4061dc96e7808ffc96dfddec1";
    }
    const { icon, title } = t0;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            opacity: 0,
            y: 40
        };
        t2 = {
            opacity: 1,
            y: 0
        };
        t3 = {
            duration: 0.6
        };
        t4 = {
            once: true
        };
        t5 = {
            scale: 1.05
        };
        $[1] = t1;
        $[2] = t2;
        $[3] = t3;
        $[4] = t4;
        $[5] = t5;
    } else {
        t1 = $[1];
        t2 = $[2];
        t3 = $[3];
        t4 = $[4];
        t5 = $[5];
    }
    let t6;
    if ($[6] !== icon) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "\r\n          w-16 h-16\r\n          sm:w-20 sm:h-20\r\n          md:w-24 md:h-24\r\n          bg-white\r\n          flex items-center justify-center\r\n          rounded-full\r\n          shadow-lg\r\n          border border-[#8c8cdc]\r\n          transition-all\r\n          duration-300\r\n          hover:bg-gray-100\r\n          hover:shadow-xl\r\n        ",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-[#5454AB] text-2xl sm:text-3xl md:text-4xl",
                children: icon
            }, void 0, false, {
                fileName: "[project]/src/components/ExpertiseSection.jsx",
                lineNumber: 112,
                columnNumber: 391
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ExpertiseSection.jsx",
            lineNumber: 112,
            columnNumber: 10
        }, this);
        $[6] = icon;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] !== title) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm font-para sm:text-base md:text-[20px] text-center font-semibold text-black leading-tight",
            children: title
        }, void 0, false, {
            fileName: "[project]/src/components/ExpertiseSection.jsx",
            lineNumber: 120,
            columnNumber: 10
        }, this);
        $[8] = title;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== t6 || $[11] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "flex flex-col items-center gap-2 sm:gap-3",
            initial: t1,
            whileInView: t2,
            transition: t3,
            viewport: t4,
            whileHover: t5,
            children: [
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ExpertiseSection.jsx",
            lineNumber: 128,
            columnNumber: 10
        }, this);
        $[10] = t6;
        $[11] = t7;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    return t8;
}
_c1 = ExpertiseCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "ExpertiseSection");
__turbopack_context__.k.register(_c1, "ExpertiseCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/FlagshipProduct.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FlagshipProduct
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/products.json (json)");
"use client";
;
;
;
;
;
function FlagshipProduct() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "95083f6f0dbec2138cdf5723e5b7cf56aa9e1e2e36f2d1fe0152893fac36be5b") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "95083f6f0dbec2138cdf5723e5b7cf56aa9e1e2e36f2d1fe0152893fac36be5b";
    }
    const slug = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$json__$28$json$29$__["default"].products[0].slug;
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            backgroundColor: "#111122"
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "\r\n            border px-6 py-2 rounded-xl mb-8\r\n            w-full max-w-[528px]\r\n          ",
            style: {
                borderColor: "#FB7704",
                color: "#FB7704",
                fontSize: "18px"
            },
            children: "FLAGSHIP PRODUCT"
        }, void 0, false, {
            fileName: "[project]/src/components/FlagshipProduct.jsx",
            lineNumber: 27,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h1, {
            className: "text-4xl sm:text-5xl font-extrabold text-white mb-4",
            initial: {
                opacity: 0,
                y: 20
            },
            animate: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: 0.35,
                duration: 0.6
            },
            children: "Insight Discovery"
        }, void 0, false, {
            fileName: "[project]/src/components/FlagshipProduct.jsx",
            lineNumber: 38,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
            className: "\r\n            text-gray-300 text-base sm:text-lg\r\n            leading-relaxed mb-6\r\n            w-full max-w-[520px]\r\n          ",
            initial: {
                opacity: 0,
                y: 15
            },
            animate: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: 0.5,
                duration: 0.6
            },
            children: "Insight Discovery is our foundational flagship offering designed to help individuals understand their core strengths, behavioural style, and unique growth opportunities."
        }, void 0, false, {
            fileName: "[project]/src/components/FlagshipProduct.jsx",
            lineNumber: 55,
            columnNumber: 10
        }, this);
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[#FB7704] text-base sm:text-lg mb-4",
            children: "Where can Insights Discovery take you?"
        }, void 0, false, {
            fileName: "[project]/src/components/FlagshipProduct.jsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "\r\n          w-full md:w-1/2\r\n          px-6 sm:px-10 md:px-20\r\n          py-12 md:py-20\r\n          flex flex-col justify-center\r\n        ",
            style: t0,
            children: [
                t1,
                t2,
                t3,
                t4,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: `/products/${slug}`,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "w-fit px-6 py-2 border border-[#FB7704] text-[#FB7704] rounded-lg hover:bg-[#FB7704] hover:text-white transition",
                        children: "Click here"
                    }, void 0, false, {
                        fileName: "[project]/src/components/FlagshipProduct.jsx",
                        lineNumber: 74,
                        columnNumber: 237
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/FlagshipProduct.jsx",
                    lineNumber: 74,
                    columnNumber: 204
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/FlagshipProduct.jsx",
            lineNumber: 74,
            columnNumber: 10
        }, this);
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            backgroundColor: "#222244"
        };
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "\r\n        w-full flex flex-col md:flex-row\r\n        min-h-[600px] md:h-[600px]\r\n      ",
            children: [
                t5,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "\r\n          w-full md:w-1/2\r\n          flex items-center justify-center\r\n          py-12 md:py-0\r\n        ",
                    style: t6,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full max-w-[520px] aspect-square",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            viewBox: "0 0 520 520",
                            width: "100%",
                            height: "100%",
                            preserveAspectRatio: "xMidYMid meet",
                            children: [
                                [
                                    {
                                        color: "#EC008C",
                                        label1: "Energetic",
                                        label2: "Bold Actions",
                                        tx: 360,
                                        ty: 150
                                    },
                                    {
                                        color: "#0072BC",
                                        label1: "Clarity",
                                        label2: "Clear Thinking",
                                        tx: 380,
                                        ty: 330
                                    },
                                    {
                                        color: "#F7941E",
                                        label1: "Inspiration",
                                        label2: "Creative Drive",
                                        tx: 135,
                                        ty: 330
                                    },
                                    {
                                        color: "#8DC63F",
                                        label1: "Harmony",
                                        label2: "Supportive Focus",
                                        tx: 160,
                                        ty: 150
                                    }
                                ].map(_FlagshipProductAnonymous),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                    cx: "260",
                                    cy: "260",
                                    r: "205",
                                    fill: "none",
                                    stroke: "#D1D1D1",
                                    strokeWidth: "12"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/FlagshipProduct.jsx",
                                    lineNumber: 114,
                                    columnNumber: 47
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                    cx: "260",
                                    cy: "260",
                                    r: "95",
                                    fill: "#2A9FD6",
                                    stroke: "#FFFFFF",
                                    strokeWidth: "3"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/FlagshipProduct.jsx",
                                    lineNumber: 114,
                                    columnNumber: 129
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                                    x: "260",
                                    y: "240",
                                    textAnchor: "middle",
                                    fill: "white",
                                    fontSize: "22",
                                    fontWeight: "bold",
                                    children: "Your Journey"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/FlagshipProduct.jsx",
                                    lineNumber: 114,
                                    columnNumber: 212
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                                    x: "260",
                                    y: "265",
                                    textAnchor: "middle",
                                    fill: "white",
                                    fontSize: "22",
                                    fontWeight: "bold",
                                    children: "Begins Here"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/FlagshipProduct.jsx",
                                    lineNumber: 114,
                                    columnNumber: 318
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                                    x: "260",
                                    y: "285",
                                    textAnchor: "middle",
                                    fill: "white",
                                    fontSize: "14",
                                    opacity: "0.9",
                                    children: "Create your own path"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/FlagshipProduct.jsx",
                                    lineNumber: 114,
                                    columnNumber: 423
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                                    x: "260",
                                    y: "300",
                                    textAnchor: "middle",
                                    fill: "white",
                                    fontSize: "14",
                                    opacity: "0.9",
                                    children: "with Insights tools"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/FlagshipProduct.jsx",
                                    lineNumber: 114,
                                    columnNumber: 533
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/FlagshipProduct.jsx",
                            lineNumber: 90,
                            columnNumber: 327
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/FlagshipProduct.jsx",
                        lineNumber: 90,
                        columnNumber: 275
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/FlagshipProduct.jsx",
                    lineNumber: 90,
                    columnNumber: 130
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/FlagshipProduct.jsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    return t7;
}
_c = FlagshipProduct;
function _FlagshipProductAnonymous(seg, i) {
    const angles = [
        -90,
        0,
        90,
        180,
        270
    ];
    const start = angles[i] * Math.PI / 180;
    const end = angles[i + 1] * Math.PI / 180;
    const x1 = 260 + 205 * Math.cos(start);
    const y1 = 260 + 205 * Math.sin(start);
    const x2 = 260 + 205 * Math.cos(end);
    const y2 = 260 + 205 * Math.sin(end);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].path, {
                d: `
                      M260 260
                      L${x1} ${y1}
                      A205 205 0 0 1 ${x2} ${y2}
                      Z
                    `,
                fill: seg.color,
                whileHover: {
                    scale: 1.03,
                    filter: "drop-shadow(0 0 20px rgba(255,255,255,0.6))"
                }
            }, void 0, false, {
                fileName: "[project]/src/components/FlagshipProduct.jsx",
                lineNumber: 129,
                columnNumber: 21
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                x: seg.tx,
                y: seg.ty,
                textAnchor: "middle",
                fill: "white",
                fontSize: "18",
                fontWeight: "bold",
                children: seg.label1
            }, void 0, false, {
                fileName: "[project]/src/components/FlagshipProduct.jsx",
                lineNumber: 137,
                columnNumber: 10
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
                x: seg.tx,
                y: seg.ty + 18,
                textAnchor: "middle",
                fill: "white",
                fontSize: "14",
                opacity: "0.9",
                children: seg.label2
            }, void 0, false, {
                fileName: "[project]/src/components/FlagshipProduct.jsx",
                lineNumber: 137,
                columnNumber: 122
            }, this)
        ]
    }, i, true, {
        fileName: "[project]/src/components/FlagshipProduct.jsx",
        lineNumber: 129,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "FlagshipProduct");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/DeliveryFormat.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DeliveryFormatSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ai/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$hi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/hi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ri/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function DeliveryFormatSection() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "8b3713f0e643ee37d85f0ab6e452700ae19eee18ae88e6f4bec916dd98c2d29c") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8b3713f0e643ee37d85f0ab6e452700ae19eee18ae88e6f4bec916dd98c2d29c";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "text-center max-w-2xl mx-auto px-4 sm:px-6",
            initial: {
                opacity: 0,
                y: -20
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                duration: 0.6
            },
            viewport: {
                once: true
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl sm:text-4xl md:text-[45px] font-semibold text-[#111122]",
                    children: "DELIVERY FORMAT"
                }, void 0, false, {
                    fileName: "[project]/src/components/DeliveryFormat.jsx",
                    lineNumber: 29,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 text-base sm:text-lg md:text-[20px] mt-2",
                    children: "Flexible approach tailored to your needs"
                }, void 0, false, {
                    fileName: "[project]/src/components/DeliveryFormat.jsx",
                    lineNumber: 29,
                    columnNumber: 109
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 19,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative container mx-auto px-4 sm:px-6 mt-14",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    width: 0
                },
                whileInView: {
                    width: "80%"
                },
                transition: {
                    duration: 1.4,
                    ease: "easeInOut"
                },
                viewport: {
                    once: true
                },
                className: "\r\n            hidden sm:block\r\n            absolute \r\n            left-1/2 \r\n            -translate-x-1/2\r\n            h-[3px] \r\n            bg-[#5454AB]/80 \r\n            rounded-full\r\n            top-[52px]\r\n            z-0\r\n          "
            }, void 0, false, {
                fileName: "[project]/src/components/DeliveryFormat.jsx",
                lineNumber: 36,
                columnNumber: 73
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 36,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                opacity: 0
            },
            whileInView: {
                opacity: 1
            },
            transition: {
                duration: 1
            },
            viewport: {
                once: true
            },
            className: "\r\n    sm:hidden\r\n    absolute\r\n    left-1/2\r\n    -translate-x-1/2\r\n    top-[40px]        /* center of first circle */\r\n    bottom-[96px]    /* center of last circle */\r\n    w-[3px]\r\n    bg-[#5454AB]/70\r\n    rounded-full\r\n    -z-10\r\n    pointer-events-none\r\n  "
        }, void 0, false, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 52,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DeliveryCard, {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiBookOpen"], {
                className: "text-[#5454AB] text-3xl sm:text-4xl"
            }, void 0, false, {
                fileName: "[project]/src/components/DeliveryFormat.jsx",
                lineNumber: 67,
                columnNumber: 30
            }, void 0),
            title: "Training",
            delay: 0.1
        }, void 0, false, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 67,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DeliveryCard, {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AiOutlineMessage"], {
                className: "text-[#5454AB] text-3xl sm:text-4xl"
            }, void 0, false, {
                fileName: "[project]/src/components/DeliveryFormat.jsx",
                lineNumber: 74,
                columnNumber: 30
            }, void 0),
            title: "Coaching",
            delay: 0.3
        }, void 0, false, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 74,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DeliveryCard, {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AiOutlineTeam"], {
                className: "text-[#5454AB] text-3xl sm:text-4xl"
            }, void 0, false, {
                fileName: "[project]/src/components/DeliveryFormat.jsx",
                lineNumber: 81,
                columnNumber: 30
            }, void 0),
            title: "Mentoring",
            delay: 0.5
        }, void 0, false, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DeliveryCard, {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$hi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HiLightBulb"], {
                className: "text-[#5454AB] text-3xl sm:text-4xl"
            }, void 0, false, {
                fileName: "[project]/src/components/DeliveryFormat.jsx",
                lineNumber: 88,
                columnNumber: 30
            }, void 0),
            title: "Consulting",
            delay: 0.7
        }, void 0, false, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "\r\n        py-25 \r\n        w-full \r\n        bg-gradient-to-b \r\n        from-[#5454AB]/10 \r\n        to-[#5454AB]/5\r\n        \r\n        relative\r\n      ",
            children: [
                t0,
                t1,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 sm:px-6 mt-12 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 relative z-10",
                    children: [
                        t2,
                        t3,
                        t4,
                        t5,
                        t6,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DeliveryCard, {
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ri$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiTeamLine"], {
                                className: "text-[#5454AB] text-3xl sm:text-4xl"
                            }, void 0, false, {
                                fileName: "[project]/src/components/DeliveryFormat.jsx",
                                lineNumber: 95,
                                columnNumber: 368
                            }, void 0),
                            title: "Facilitation",
                            delay: 0.9
                        }, void 0, false, {
                            fileName: "[project]/src/components/DeliveryFormat.jsx",
                            lineNumber: 95,
                            columnNumber: 348
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/DeliveryFormat.jsx",
                    lineNumber: 95,
                    columnNumber: 206
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 95,
            columnNumber: 10
        }, this);
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    return t7;
}
_c = DeliveryFormatSection;
// ---------- CARD COMPONENT ----------
function DeliveryCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "8b3713f0e643ee37d85f0ab6e452700ae19eee18ae88e6f4bec916dd98c2d29c") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8b3713f0e643ee37d85f0ab6e452700ae19eee18ae88e6f4bec916dd98c2d29c";
    }
    const { icon, title, delay } = t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            opacity: 0,
            scale: 0.5
        };
        t2 = {
            opacity: 1,
            scale: 1
        };
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    let t3;
    if ($[3] !== delay) {
        t3 = {
            duration: 0.5,
            delay,
            ease: "easeOut"
        };
        $[3] = delay;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            once: true
        };
        t5 = {
            scale: 1.08
        };
        $[5] = t4;
        $[6] = t5;
    } else {
        t4 = $[5];
        t5 = $[6];
    }
    let t6;
    if ($[7] !== icon) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "\r\n          w-20 h-20 sm:w-24 sm:h-24\r\n          bg-white \r\n          flex items-center justify-center \r\n          rounded-full \r\n          shadow-lg \r\n          border-4 border-[#5454AB]\r\n          transition-all \r\n          duration-300 \r\n          hover:bg-gray-100 \r\n          hover:shadow-2xl\r\n        ",
            children: icon
        }, void 0, false, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 163,
            columnNumber: 10
        }, this);
        $[7] = icon;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== title) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[16px] sm:text-[18px] text-center text-black font-semibold",
            children: title
        }, void 0, false, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 171,
            columnNumber: 10
        }, this);
        $[9] = title;
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== t3 || $[12] !== t6 || $[13] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "flex flex-col items-center gap-3",
            initial: t1,
            whileInView: t2,
            transition: t3,
            viewport: t4,
            whileHover: t5,
            children: [
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/DeliveryFormat.jsx",
            lineNumber: 179,
            columnNumber: 10
        }, this);
        $[11] = t3;
        $[12] = t6;
        $[13] = t7;
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    return t8;
}
_c1 = DeliveryCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "DeliveryFormatSection");
__turbopack_context__.k.register(_c1, "DeliveryCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/WhyTalendor.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WhyTalendor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
"use client";
;
;
;
function WhyTalendor() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(33);
    if ($[0] !== "878d433670ea1eec455866205ec86ced1ab1ee8716b15cddc9490d7094af8e81") {
        for(let $i = 0; $i < 33; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "878d433670ea1eec455866205ec86ced1ab1ee8716b15cddc9490d7094af8e81";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "\r\n          absolute bottom-0 right-0\r\n          w-[350px] h-[350px] md:w-[550px] md:h-[550px]\r\n          rounded-full opacity-70 bg-gradient-to-br\r\n          from-[#6A6AFF]/50 via-[#867AE6]/40 to-[#B0A7FF]/35\r\n          blur-[100px] md:blur-[130px]\r\n        "
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 15,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h2, {
            initial: {
                opacity: 0,
                y: -20
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                duration: 0.6
            },
            className: "text-3xl sm:text-4xl font-bold mb-6 md:mt-2",
            children: "Why Talendor?"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 22,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
            initial: {
                opacity: 0,
                y: 20
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: 0.2,
                duration: 0.6
            },
            className: "\r\n            text-gray-300 text-base sm:text-lg\r\n            leading-relaxed max-w-2xl\r\n            mb-12 mx-auto md:mx-0\r\n          ",
            children: "Your people are your greates asset.At Talendor, we blend innovation with human-centric solution to create workplace thrive.Partners with us to unlock your organization's full potential."
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 37,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    let t4;
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            opacity: 0,
            y: 30
        };
        t4 = {
            opacity: 1,
            y: 0
        };
        t5 = {
            delay: 0.4,
            duration: 0.7
        };
        $[4] = t3;
        $[5] = t4;
        $[6] = t5;
    } else {
        t3 = $[4];
        t4 = $[5];
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-lg font-semibold mb-3",
            children: "Client Impact Analysis"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 77,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t16;
    let t17;
    let t18;
    let t19;
    let t7;
    let t8;
    let t9;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = [
            40,
            75,
            110,
            145,
            180,
            215,
            250
        ].map(_WhyTalendorAnonymous);
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "4",
            y: "45",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "65"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "4",
            y: "80",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "70"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 98,
            columnNumber: 10
        }, this);
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "4",
            y: "115",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "75"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 99,
            columnNumber: 11
        }, this);
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "4",
            y: "150",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "80"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 100,
            columnNumber: 11
        }, this);
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "4",
            y: "185",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "85"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 101,
            columnNumber: 11
        }, this);
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "4",
            y: "220",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "90"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 102,
            columnNumber: 11
        }, this);
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "4",
            y: "255",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "95"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 103,
            columnNumber: 11
        }, this);
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "70",
            y: "270",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "Q1"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 104,
            columnNumber: 11
        }, this);
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "160",
            y: "270",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "Q2"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 105,
            columnNumber: 11
        }, this);
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "260",
            y: "270",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "Q3"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 106,
            columnNumber: 11
        }, this);
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "360",
            y: "270",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "Q4"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 107,
            columnNumber: 11
        }, this);
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("text", {
            x: "450",
            y: "270",
            fill: "#BBBBBB",
            fontSize: "10",
            children: "Q5"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 108,
            columnNumber: 11
        }, this);
        $[8] = t10;
        $[9] = t11;
        $[10] = t12;
        $[11] = t13;
        $[12] = t14;
        $[13] = t15;
        $[14] = t16;
        $[15] = t17;
        $[16] = t18;
        $[17] = t19;
        $[18] = t7;
        $[19] = t8;
        $[20] = t9;
    } else {
        t10 = $[8];
        t11 = $[9];
        t12 = $[10];
        t13 = $[11];
        t14 = $[12];
        t15 = $[13];
        t16 = $[14];
        t17 = $[15];
        t18 = $[16];
        t19 = $[17];
        t7 = $[18];
        t8 = $[19];
        t9 = $[20];
    }
    let t20;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                id: "softOrange",
                x1: "0",
                y1: "0",
                x2: "0",
                y2: "1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                        offset: "0%",
                        stopColor: "#FF7A00",
                        stopOpacity: "0.35"
                    }, void 0, false, {
                        fileName: "[project]/src/components/WhyTalendor.jsx",
                        lineNumber: 139,
                        columnNumber: 77
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                        offset: "100%",
                        stopColor: "#FF7A00",
                        stopOpacity: "0.08"
                    }, void 0, false, {
                        fileName: "[project]/src/components/WhyTalendor.jsx",
                        lineNumber: 139,
                        columnNumber: 136
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/WhyTalendor.jsx",
                lineNumber: 139,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 139,
            columnNumber: 11
        }, this);
        $[21] = t20;
    } else {
        t20 = $[21];
    }
    let t21;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].path, {
            d: "\r\n                  M40 250\r\n                  L40 200\r\n                  L140 160\r\n                  L240 120\r\n                  L330 80\r\n                  L420 55\r\n                  L500 40\r\n                  L500 250 Z\r\n                ",
            fill: "url(#softOrange)",
            initial: {
                opacity: 0,
                scaleY: 0,
                originY: 1
            },
            whileInView: {
                opacity: 1,
                scaleY: 1
            },
            transition: {
                duration: 1.8
            }
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 146,
            columnNumber: 11
        }, this);
        $[22] = t21;
    } else {
        t21 = $[22];
    }
    let t22;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "\r\n        relative mt-15 md:mt-0 z-10 max-w-4xl text-white\r\n          md:ml-6 text-center md:text-left px-4\r\n        ",
            children: [
                t1,
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: t3,
                    whileInView: t4,
                    transition: t5,
                    className: "\r\n            w-full max-w-xl sm:max-w-2xl \r\n            h-[300px] sm:h-[330px] \r\n            p-4 sm:p-6 rounded-2xl \r\n            backdrop-blur-2xl bg-white/10 border border-white/20\r\n            mx-auto md:mx-0\r\n          ",
                    children: [
                        t6,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: " w-full h-[220px] sm:h-[260px] overflow-hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                width: "100%",
                                height: "100%",
                                viewBox: "0 0 500 260",
                                preserveAspectRatio: "none",
                                children: [
                                    t7,
                                    t8,
                                    t9,
                                    t10,
                                    t11,
                                    t12,
                                    t13,
                                    t14,
                                    t15,
                                    t16,
                                    t17,
                                    t18,
                                    t19,
                                    t20,
                                    t21,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].path, {
                                        d: "\r\n                  M40 200 \r\n                  L140 160 \r\n                  L240 120 \r\n                  L330 80 \r\n                  L420 55 \r\n                  L500 40\r\n                ",
                                        stroke: "#FF7A00",
                                        strokeWidth: "4",
                                        fill: "none",
                                        initial: {
                                            pathLength: 0
                                        },
                                        whileInView: {
                                            pathLength: 1
                                        },
                                        transition: {
                                            duration: 1.5
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/WhyTalendor.jsx",
                                        lineNumber: 162,
                                        columnNumber: 692
                                    }, this),
                                    [
                                        [
                                            40,
                                            200
                                        ],
                                        [
                                            140,
                                            160
                                        ],
                                        [
                                            240,
                                            120
                                        ],
                                        [
                                            330,
                                            80
                                        ],
                                        [
                                            420,
                                            55
                                        ],
                                        [
                                            500,
                                            40
                                        ]
                                    ].map(_WhyTalendorAnonymous2)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/WhyTalendor.jsx",
                                lineNumber: 162,
                                columnNumber: 539
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/WhyTalendor.jsx",
                            lineNumber: 162,
                            columnNumber: 475
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/WhyTalendor.jsx",
                    lineNumber: 162,
                    columnNumber: 162
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 162,
            columnNumber: 11
        }, this);
        $[23] = t22;
    } else {
        t22 = $[23];
    }
    let t23;
    let t24;
    let t25;
    let t26;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = {
            scale: 0.7,
            opacity: 0
        };
        t24 = {
            scale: 1,
            opacity: 1
        };
        t25 = {
            duration: 1
        };
        t26 = {
            once: true
        };
        $[24] = t23;
        $[25] = t24;
        $[26] = t25;
        $[27] = t26;
    } else {
        t23 = $[24];
        t24 = $[25];
        t25 = $[26];
        t26 = $[27];
    }
    let t27;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "\r\n                absolute top-[-18px] sm:top-[-25px]\r\n                left-1/2 -translate-x-1/2\r\n                px-3 py-1 md:px-3 md:py-3 rounded-full\r\n                backdrop-blur-xl bg-white/10 border border-white/20\r\n                text-white text-xs\r\n              ",
            animate: {
                y: [
                    0,
                    -10,
                    0
                ]
            },
            transition: {
                duration: 2.6,
                repeat: Infinity
            },
            children: "Global Expertise"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 204,
            columnNumber: 11
        }, this);
        $[28] = t27;
    } else {
        t27 = $[28];
    }
    let t28;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "\r\n    absolute\r\n    left-[-65px] sm:left-[-50px]\r\n    top-1/2 -translate-y-1/2\r\n    px-2 py-2 md:px-2 md:py-3 sm:px-3 sm:py-2\r\n    max-w-[110px] sm:max-w-none\r\n    rounded-full\r\n    text-center\r\n    backdrop-blur-xl bg-white/10 border border-white/20\r\n    text-[10px] sm:text-xs\r\n    text-white\r\n    scale-90 sm:scale-100\r\n    leading-tight\r\n  ",
            animate: {
                y: [
                    0,
                    -10,
                    0
                ]
            },
            transition: {
                duration: 2.6,
                repeat: Infinity
            },
            children: "Future Ready Thinking"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 216,
            columnNumber: 11
        }, this);
        $[29] = t28;
    } else {
        t28 = $[29];
    }
    let t29;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "\r\n    absolute\r\n    right-[-45px] sm:right-[-50px]\r\n    top-1/2 -translate-y-1/2\r\n    px-3 py-3 md:px-4 md:py-3 sm:px-3 sm:py-2\r\n    max-w-[110px] sm:max-w-none\r\n    rounded-full\r\n    text-center\r\n    backdrop-blur-xl bg-white/10 border border-white/20\r\n    text-[10px] sm:text-xs\r\n    text-white\r\n    scale-90 sm:scale-100\r\n    leading-tight\r\n  ",
            animate: {
                y: [
                    0,
                    -10,
                    0
                ]
            },
            transition: {
                duration: 2.6,
                repeat: Infinity
            },
            children: "People First"
        }, void 0, false, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 228,
            columnNumber: 11
        }, this);
        $[30] = t29;
    } else {
        t29 = $[30];
    }
    let t30;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "\r\n                w-[170px] h-[170px]\r\n                sm:w-[240px] sm:h-[240px]\r\n                md:w-[360px] md:h-[360px]\r\n                rounded-full border border-[#5454AB]\r\n                flex items-center justify-center relative\r\n              ",
            children: [
                t28,
                t29,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "\r\n                  w-[120px] h-[120px]\r\n                  sm:w-[180px] sm:h-[180px]\r\n                  md:w-[280px] md:h-[280px]\r\n                  rounded-full border border-[#FF7A00]\r\n                  flex items-center justify-center\r\n                ",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-center text-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-3xl sm:text-5xl md:text-6xl font-bold",
                                children: "20+"
                            }, void 0, false, {
                                fileName: "[project]/src/components/WhyTalendor.jsx",
                                lineNumber: 240,
                                columnNumber: 661
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs sm:text-sm text-gray-400 text-center",
                                children: "Years of Global Experience"
                            }, void 0, false, {
                                fileName: "[project]/src/components/WhyTalendor.jsx",
                                lineNumber: 240,
                                columnNumber: 728
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/WhyTalendor.jsx",
                        lineNumber: 240,
                        columnNumber: 606
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/WhyTalendor.jsx",
                    lineNumber: 240,
                    columnNumber: 312
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 240,
            columnNumber: 11
        }, this);
        $[31] = t30;
    } else {
        t30 = $[31];
    }
    let t31;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "\r\n        relative w-full min-h-[700px] md:h-[700px]\r\n        py-20 px-4 md:px-6\r\n        bg-[#111122] overflow-hidden\r\n      ",
            children: [
                t0,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col md:block",
                    children: [
                        t22,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "\r\n            order-2 md:order-none\r\n            relative z-0 mt-16 md:mt-0\r\n            md:absolute md:right-25 md:top-1/2 md:-translate-y-1/2\r\n            flex items-center justify-center\r\n          ",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                className: "\r\n              w-[220px] h-[220px]\r\n              sm:w-[300px] sm:h-[300px]\r\n              md:w-[450px] md:h-[450px]\r\n              rounded-full border border-[#2039b8]/90\r\n              flex items-center justify-center relative\r\n            ",
                                initial: t23,
                                whileInView: t24,
                                transition: t25,
                                viewport: t26,
                                children: [
                                    t27,
                                    t30,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                        className: "\r\n                absolute bottom-[-18px] sm:bottom-[-30px]\r\n                left-1/2 -translate-x-1/2\r\n                px-10 py-1 md:px-10 md:py-3 rounded-full\r\n                backdrop-blur-xl bg-white/10 border border-white/20\r\n                text-white text-xs\r\n              ",
                                        animate: {
                                            y: [
                                                0,
                                                12,
                                                0
                                            ]
                                        },
                                        transition: {
                                            duration: 2.6,
                                            repeat: Infinity
                                        },
                                        children: "Bespoke Approach"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/WhyTalendor.jsx",
                                        lineNumber: 247,
                                        columnNumber: 805
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/WhyTalendor.jsx",
                                lineNumber: 247,
                                columnNumber: 449
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/WhyTalendor.jsx",
                            lineNumber: 247,
                            columnNumber: 218
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/WhyTalendor.jsx",
                    lineNumber: 247,
                    columnNumber: 173
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/WhyTalendor.jsx",
            lineNumber: 247,
            columnNumber: 11
        }, this);
        $[32] = t31;
    } else {
        t31 = $[32];
    }
    return t31;
}
_c = WhyTalendor;
function _WhyTalendorAnonymous2(t0, i) {
    const [x, y_0] = t0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
        cx: x,
        cy: y_0,
        r: "5",
        fill: "#FF7A00"
    }, i, false, {
        fileName: "[project]/src/components/WhyTalendor.jsx",
        lineNumber: 261,
        columnNumber: 10
    }, this);
}
function _WhyTalendorAnonymous(y) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
        x1: "40",
        y1: y,
        x2: "500",
        y2: y,
        stroke: "rgba(255,255,255,0.10)",
        strokeWidth: "1"
    }, y, false, {
        fileName: "[project]/src/components/WhyTalendor.jsx",
        lineNumber: 264,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "WhyTalendor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data/founders.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"founders":[{"name":"Anita Chandola","title":"Executive Search Consultant","slug":"anita-chandola","description":["Anita has spent nearly 15 years to find best fit talent for organizations from different industries including FMCG, Hospitality, Management Consulting, Banking, Aviation, etc.","Anita is a passionate Executive Search Consultant and loves to spend time with family, friends and singing."],"image":"/images/anita_chandola.webp","experienceSummary":["With 20+ years of global HR experience, Praveen is passionate about people and organizational development, he has held key roles including Head HR, HR Business Partner across India, APAC, Middle East, Russia, and Latin America, and Global HR CoE Leader at Sennheiser.","Expert in building scalable processes, driving global talent strategies, and enabling cultural and organizational transformation.","Self-driven, self-aware, nature and adventure lover with continuous learning mindset and humble attitude.","Foundation Team member of India entity & build HR foundations across regions.","Led, developed & implemented global talent, leadership, and performance programs.","Driven multiple large global culture transformation and org redesign.","Successfully planned & executed complex business M&A & carve-outs.","Delivered HR digital transformation via HRIS, LMS & Intranet.","Core Global team member of DEI, wellbeing, and sustainability initiatives.","Enhanced talent acquisition, retention, and L&D impact.","Trusted partner to business leaders, aligning HR & business strategy."],"continuousLearning":["2550 hours Training & Facilitation Experience","310 hours of Coaching Experience","Performance Management, IIM Kolkata","Master Trainer & Facilitator, Dale Carnegie","Master Coach, Erickson International","Insights Discovery Psychometric, UK","Team Management Systems, Australia","NLP Practitioner, NFNLP","Competence Developer, Carlton University","Inner Engineering, Isha Foundation","Being Centered Leader, Impossible TF","PGC HR, XLRI","Science Graduate, HNBGU"],"contact":{"mobile":"+91-9818711851","email":"praveen@talendor.in"}},{"name":"Praveen Chandola","title":"Strategic HR Consultant, Executive Coach & Trainer","slug":"praveen-chandola","description":["Praveen is a results-driven HR professional, Executive Coach & Trainer with 20+ years of strategic global experience in Human Resource and Operations.","Praveen is self-driven, nature and adventure lover, continues learning mindset person with humble attitude towards life."],"image":"/images/praveen_chandola.webp","experienceSummary":["With 20+ years of global HR experience, Praveen is passionate about people and organizational development, he has held key roles including Head HR, HR Business Partner across India, APAC, Middle East, Russia, and Latin America, and Global HR CoE Leader at Sennheiser.","Expert in building scalable processes, driving global talent strategies, and enabling cultural and organizational transformation.","Self-driven, self-aware, nature and adventure lover with continuous learning mindset and humble attitude.","Foundation Team member of India entity & build HR foundations across regions.","Led, developed & implemented global talent, leadership, and performance programs.","Driven multiple large global culture transformation and org redesign.","Successfully planned & executed complex business M&A & carve-outs.","Delivered HR digital transformation via HRIS, LMS & Intranet.","Core Global team member of DEI, wellbeing, and sustainability initiatives.","Enhanced talent acquisition, retention, and L&D impact.","Trusted partner to business leaders, aligning HR & business strategy."],"continuousLearning":["2550 hours Training & Facilitation Experience","310 hours of Coaching Experience","Performance Management, IIM Kolkata","Master Trainer & Facilitator, Dale Carnegie","Master Coach, Erickson International","Insights Discovery Psychometric, UK","Team Management Systems, Australia","NLP Practitioner, NFNLP","Competence Developer, Carlton University","Inner Engineering, Isha Foundation","Being Centered Leader, Impossible TF","PGC HR, XLRI","Science Graduate, HNBGU"],"contact":{"mobile":"+91-9818711851","email":"praveen@talendor.in"}}]});}),
"[project]/src/components/Founders.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/founders.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const Founders = ()=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(31);
    if ($[0] !== "af10d59a90aca05456e5d786a5daba5c49512067fc38e5de367b6d78ef7d1a74") {
        for(let $i = 0; $i < 31; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "af10d59a90aca05456e5d786a5daba5c49512067fc38e5de367b6d78ef7d1a74";
    }
    const [index, setIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    let t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = ()=>{
            const timer = setInterval(()=>{
                setIndex(_temp);
            }, 4000);
            return ()=>clearInterval(timer);
        };
        t1 = [];
        $[1] = t0;
        $[2] = t1;
    } else {
        t0 = $[1];
        t1 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    let t2;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            opacity: 0,
            x: ("TURBOPACK compile-time value", "object") !== "undefined" && window.innerWidth < 768 ? 40 : 100
        };
        t3 = {
            opacity: 1,
            x: 0
        };
        $[3] = t2;
        $[4] = t3;
    } else {
        t2 = $[3];
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            enter: t2,
            center: t3,
            exit: {
                opacity: 0,
                x: ("TURBOPACK compile-time value", "object") !== "undefined" && window.innerWidth < 768 ? -40 : -100
            }
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const variants = t4;
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            duration: 0.6,
            ease: "easeInOut"
        };
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    const t6 = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__["default"].founders[index];
    const t7 = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__["default"].founders[index];
    let t8;
    if ($[7] !== t6.image || $[8] !== t7.name) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full md:w-1/3 h-80 md:h-auto ",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: t6.image,
                alt: t7.name,
                className: "w-full h-full object-cover"
            }, void 0, false, {
                fileName: "[project]/src/components/Founders.jsx",
                lineNumber: 80,
                columnNumber: 59
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 80,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[7] = t6.image;
        $[8] = t7.name;
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    const t9 = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__["default"].founders[index];
    let t10;
    if ($[10] !== t9.name) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-xl md:text-2xl font-bold text-[#111122]",
            children: t9.name
        }, void 0, false, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 90,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[10] = t9.name;
        $[11] = t10;
    } else {
        t10 = $[11];
    }
    const t11 = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__["default"].founders[index];
    let t12;
    if ($[12] !== t11.title) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[#FB7704] text-base md:text-lg mb-2 md:mb-4",
            children: t11.title
        }, void 0, false, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 99,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[12] = t11.title;
        $[13] = t12;
    } else {
        t12 = $[13];
    }
    const t13 = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__["default"].founders[index];
    let t14;
    if ($[14] !== t13.description) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[#4F4F4A] text-sm md:text-base leading-relaxed",
            children: t13.description
        }, void 0, false, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 108,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[14] = t13.description;
        $[15] = t14;
    } else {
        t14 = $[15];
    }
    let t15;
    if ($[16] !== t10 || $[17] !== t12 || $[18] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t10,
                t12,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 116,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[16] = t10;
        $[17] = t12;
        $[18] = t14;
        $[19] = t15;
    } else {
        t15 = $[19];
    }
    const t16 = `/founders/${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__["default"].founders[index].slug}`;
    let t17;
    if ($[20] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-3 md:mt-4 flex gap-4 text-[#4F4F4A]",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: t16,
                className: "text-blue-500 text-sm md:text-base",
                children: "Learn more"
            }, void 0, false, {
                fileName: "[project]/src/components/Founders.jsx",
                lineNumber: 127,
                columnNumber: 67
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 127,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[20] = t16;
        $[21] = t17;
    } else {
        t17 = $[21];
    }
    let t18;
    if ($[22] !== t15 || $[23] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "md:w-2/3 p-4 md:p-6 flex flex-col justify-between gap-2",
            children: [
                t15,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 135,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[22] = t15;
        $[23] = t17;
        $[24] = t18;
    } else {
        t18 = $[24];
    }
    let t19;
    if ($[25] !== t18 || $[26] !== t8) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col md:flex-row bg-white rounded-xl shadow-lg overflow-hidden w-full max-w-4xl",
            children: [
                t8,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 144,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[25] = t18;
        $[26] = t8;
        $[27] = t19;
    } else {
        t19 = $[27];
    }
    let t20;
    if ($[28] !== index || $[29] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "px-4 md:px-10 py-10 md:py-20 bg-gradient-to-b from-gray-300 to-white overflow-x-hidden",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full flex justify-center overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                    mode: "wait",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        variants: variants,
                        initial: "enter",
                        animate: "center",
                        exit: "exit",
                        transition: t5,
                        className: "w-full flex justify-center",
                        children: t19
                    }, index, false, {
                        fileName: "[project]/src/components/Founders.jsx",
                        lineNumber: 153,
                        columnNumber: 217
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/Founders.jsx",
                    lineNumber: 153,
                    columnNumber: 188
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/Founders.jsx",
                lineNumber: 153,
                columnNumber: 119
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/Founders.jsx",
            lineNumber: 153,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[28] = index;
        $[29] = t19;
        $[30] = t20;
    } else {
        t20 = $[30];
    }
    return t20;
};
_s(Founders, "c3fuAdVwNN91t4bNS1qBXl5hAWY=");
_c = Founders;
const __TURBOPACK__default__export__ = Founders;
function _temp(prev) {
    return (prev + 1) % __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$founders$2e$json__$28$json$29$__["default"].founders.length;
}
var _c;
__turbopack_context__.k.register(_c, "Founders");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data/scrollsection.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v([{"slug":"strategic-hr-consulting","title":"STRATEGIC HR CONSULTING SERVICES","description":"Build core leadership fundamentals for emerging leaders.","bullets":["Excutive and Leadership Services","Unleasing Talent Potential","Future-Ready Organization","Business-Enbaling Strategy"],"image":"/images/team.webp"},{"slug":"leadership-development-journeys","title":"LEADERSHIP DEVELOPMENT JOURNEYS ","description":"Shift workloads to the cloud securely with automated best-practice deployment frameworks.","bullets":["Foundational Leadership Program","Advance Leadership Program","Executive & C-Suite Development","Global, Inclusive & Cross-Culture Leadership","Discovering Self & Executive Presence","Leading Teams & Building Thriving Cultures","Thriving in Bussiness Leadereship"],"image":"/images/leader.webp"},{"slug":"reskilling-programs","title":"RESKILLING PROGRAMS","description":"Build modern data platforms with real-time, AI-driven intelligence for enterprise scale.","bullets":["Leading self in VUCA/BANI","Stategic Capability & Commercial Impact","Self-Mastery & Mindset Expansion","Undestanding Generational Differences ","Working Effectively with GenZ","Reverse Metoring & Inclusive Innovation","Working Smarter"],"image":"/images/soft-skills.webp"},{"slug":"team-development-journeys","title":"TEAM DEVLOPMENT JOURNEYS","description":"Build modern data platforms with real-time, AI-driven intelligence for enterprise scale.","bullets":["Foundations of Team Happiness & Trust","Builinding Multigenerational Teams","Thriving & High-Performing Teams"],"image":"/images/collaboration.webp"},{"slug":"wellbeing","title":"WELBEING","description":"Build modern data platforms with real-time, AI-driven intelligence for enterprise scale.","bullets":["Retreats","Stress Management","Emotional Intelligence","Resillience Building","Work-Life Balance","Financial Wellness","Social Connection"],"image":"/images/consultant.webp"},{"slug":"coaching-mentoring","title":"KEY COACHING & MENTORING OFFERINGS","description":"Build modern data platforms with real-time, AI-driven intelligence for enterprise scale.","bullets":["Individual Development Coaching","Onboarding Transition Coaching","Job Role Transition Coaching","Leadership Development Coaching","Career Coaching","Young HR Professional Mentoring","Fututre HR Leader Metoring"],"image":"/images/growth.webp"},{"slug":"customer-delight-programs","title":"CUSTOMER DELIGHT PROGRAMS","description":"Build modern data platforms with real-time, AI-driven intelligence for enterprise scale.","bullets":["Moments of Magic","Customer Delight Journey","Service Exellence"],"image":"/images/user-experience.webp"}]);}),
"[project]/src/components/ScrollingShowCase.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ScrollingShowcase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$scrollsection$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/scrollsection.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ScrollingShowcase() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    if ($[0] !== "f6c0e91e4c79de4eb2fd89391b0ed1049674f75f1e1d355a9135a6846c82ed81") {
        for(let $i = 0; $i < 30; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f6c0e91e4c79de4eb2fd89391b0ed1049674f75f1e1d355a9135a6846c82ed81";
    }
    const [activeIndex, setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [showPinned, setShowPinned] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const refs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t0);
    let t1;
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ScrollingShowcase[useEffect()]": ()=>{
                const observer = new IntersectionObserver((entries)=>{
                    entries.forEach({
                        "ScrollingShowcase[useEffect() > <anonymous> > entries.forEach()]": (entry)=>{
                            const index = Number(entry.target.dataset.index);
                            if (entry.isIntersecting) {
                                setActiveIndex(index);
                                setShowPinned(true);
                            }
                            if (index === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$scrollsection$2e$json__$28$json$29$__["default"].length - 1 && entry.boundingClientRect.top < 0 && !entry.isIntersecting) {
                                setShowPinned(false);
                            }
                            if (index === 0 && entry.boundingClientRect.top > 0 && !entry.isIntersecting) {
                                setShowPinned(false);
                            }
                        }
                    }["ScrollingShowcase[useEffect() > <anonymous> > entries.forEach()]"]);
                }, {
                    threshold: 0.6
                });
                refs.current.forEach({
                    "ScrollingShowcase[useEffect() > refs.current.forEach()]": (el)=>el && observer.observe(el)
                }["ScrollingShowcase[useEffect() > refs.current.forEach()]"]);
                return ()=>observer.disconnect();
            }
        })["ScrollingShowcase[useEffect()]"];
        t2 = [];
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "md:hidden px-5 py-16 space-y-10",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-2xl font-extrabold text-black font-heading bg-clip-text  text-center",
                    children: "Services"
                }, void 0, false, {
                    fileName: "[project]/src/components/ScrollingShowCase.jsx",
                    lineNumber: 66,
                    columnNumber: 59
                }, this),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$scrollsection$2e$json__$28$json$29$__["default"].map(_ScrollingShowcaseScrollSectionsMap)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ScrollingShowCase.jsx",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            opacity: 0,
            x: -50
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== showPinned) {
        t5 = showPinned ? {
            opacity: 1,
            x: 0
        } : {
            opacity: 0,
            x: -50
        };
        $[6] = showPinned;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    let t7;
    let t8;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            duration: 0.6,
            ease: "easeOut"
        };
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-2xl lg:text-5xl font-heading  bg-clip-text ",
            children: "Services"
        }, void 0, false, {
            fileName: "[project]/src/components/ScrollingShowCase.jsx",
            lineNumber: 103,
            columnNumber: 10
        }, this);
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mt-3 text-base lg:text-lg text-gray-500",
            children: "Comprehensive for your organization"
        }, void 0, false, {
            fileName: "[project]/src/components/ScrollingShowCase.jsx",
            lineNumber: 104,
            columnNumber: 10
        }, this);
        $[8] = t6;
        $[9] = t7;
        $[10] = t8;
    } else {
        t6 = $[8];
        t7 = $[9];
        t8 = $[10];
    }
    let t9;
    if ($[11] !== t5) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "sticky top-1/2 -translate-y-1/2 h-fit",
            initial: t4,
            animate: t5,
            transition: t6,
            children: [
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ScrollingShowCase.jsx",
            lineNumber: 115,
            columnNumber: 10
        }, this);
        $[11] = t5;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            opacity: 0,
            scale: 0.9
        };
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] !== showPinned) {
        t11 = showPinned ? {
            opacity: 1,
            scale: 1
        } : {
            opacity: 0,
            scale: 0.9
        };
        $[14] = showPinned;
        $[15] = t11;
    } else {
        t11 = $[15];
    }
    let t12;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            duration: 0.4
        };
        $[16] = t12;
    } else {
        t12 = $[16];
    }
    const t13 = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$scrollsection$2e$json__$28$json$29$__["default"][activeIndex];
    let t14;
    let t15;
    let t16;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = {
            opacity: 0
        };
        t15 = {
            opacity: 1
        };
        t16 = {
            duration: 0.3
        };
        $[17] = t14;
        $[18] = t15;
        $[19] = t16;
    } else {
        t14 = $[17];
        t15 = $[18];
        t16 = $[19];
    }
    let t17;
    if ($[20] !== activeIndex || $[21] !== t13.image) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].img, {
            src: t13.image,
            alt: "",
            className: "w-56 h-56 lg:w-72 lg:h-72 object-contain",
            initial: t14,
            animate: t15,
            transition: t16
        }, activeIndex, false, {
            fileName: "[project]/src/components/ScrollingShowCase.jsx",
            lineNumber: 178,
            columnNumber: 11
        }, this);
        $[20] = activeIndex;
        $[21] = t13.image;
        $[22] = t17;
    } else {
        t17 = $[22];
    }
    let t18;
    if ($[23] !== t11 || $[24] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "sticky top-1/2 -translate-y-1/2 h-fit flex justify-center",
            initial: t10,
            animate: t11,
            transition: t12,
            children: t17
        }, void 0, false, {
            fileName: "[project]/src/components/ScrollingShowCase.jsx",
            lineNumber: 187,
            columnNumber: 11
        }, this);
        $[23] = t11;
        $[24] = t17;
        $[25] = t18;
    } else {
        t18 = $[25];
    }
    let t19;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col",
            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$scrollsection$2e$json__$28$json$29$__["default"].map({
                "ScrollingShowcase[scrollSections.map()]": (item_0, i_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: {
                            "ScrollingShowcase[scrollSections.map() > <div>.ref]": (el_0)=>refs.current[i_0] = el_0
                        }["ScrollingShowcase[scrollSections.map() > <div>.ref]"],
                        "data-index": i_0,
                        className: "min-h-screen flex flex-col justify-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl lg:text-3xl font-semibold text-[#5c5cda] mb-4",
                                children: item_0.title
                            }, void 0, false, {
                                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                                lineNumber: 199,
                                columnNumber: 138
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-600 mb-4",
                                children: item_0.description
                            }, void 0, false, {
                                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                                lineNumber: 199,
                                columnNumber: 228
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "space-y-2",
                                children: item_0.bullets.map(_ScrollingShowcaseScrollSectionsMapItem_0BulletsMap)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                                lineNumber: 199,
                                columnNumber: 286
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: `/services/${item_0.slug}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "mt-6 w-fit bg-[#5454AB] text-white px-6 py-2 rounded-full",
                                    children: "Learn more"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ScrollingShowCase.jsx",
                                    lineNumber: 199,
                                    columnNumber: 430
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                                lineNumber: 199,
                                columnNumber: 390
                            }, this)
                        ]
                    }, item_0.slug, true, {
                        fileName: "[project]/src/components/ScrollingShowCase.jsx",
                        lineNumber: 197,
                        columnNumber: 69
                    }, this)
            }["ScrollingShowcase[scrollSections.map()]"])
        }, void 0, false, {
            fileName: "[project]/src/components/ScrollingShowCase.jsx",
            lineNumber: 196,
            columnNumber: 11
        }, this);
        $[26] = t19;
    } else {
        t19 = $[26];
    }
    let t20;
    if ($[27] !== t18 || $[28] !== t9) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "relative bg-white",
            children: [
                t3,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "\r\n          hidden md:grid\r\n          grid-cols-[1fr_1fr_2fr]\r\n          gap-10 lg:gap-16\r\n          px-10 lg:px-24\r\n          py-24 lg:py-32\r\n        ",
                    children: [
                        t9,
                        t18,
                        t19
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ScrollingShowCase.jsx",
                    lineNumber: 207,
                    columnNumber: 54
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ScrollingShowCase.jsx",
            lineNumber: 207,
            columnNumber: 11
        }, this);
        $[27] = t18;
        $[28] = t9;
        $[29] = t20;
    } else {
        t20 = $[29];
    }
    return t20;
}
_s(ScrollingShowcase, "Lm+mN1y4mwgBwlglH9ad49TCiXM=");
_c = ScrollingShowcase;
function _ScrollingShowcaseScrollSectionsMapItem_0BulletsMap(b_0, idx) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        className: "flex gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sky-500",
                children: "•"
            }, void 0, false, {
                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                lineNumber: 217,
                columnNumber: 47
            }, this),
            b_0
        ]
    }, idx, true, {
        fileName: "[project]/src/components/ScrollingShowCase.jsx",
        lineNumber: 217,
        columnNumber: 10
    }, this);
}
function _ScrollingShowcaseScrollSectionsMap(item) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-2xl shadow-md p-6 space-y-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: item.image,
                alt: item.title,
                className: "w-36 h-36 mx-auto object-contain"
            }, void 0, false, {
                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                lineNumber: 220,
                columnNumber: 88
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl  font-heading text-[#5c5cda] text-center",
                children: item.title
            }, void 0, false, {
                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                lineNumber: 220,
                columnNumber: 174
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gray-600 text-sm text-center",
                children: item.description
            }, void 0, false, {
                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                lineNumber: 220,
                columnNumber: 256
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "space-y-2 text-sm",
                children: item.bullets.map(_ScrollingShowcaseScrollSectionsMapItemBulletsMap)
            }, void 0, false, {
                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                lineNumber: 220,
                columnNumber: 327
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: `/services/${item.slug}`,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "bg-[#5454AB] text-white px-6 py-2 rounded-full text-sm",
                        children: "Learn more"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ScrollingShowCase.jsx",
                        lineNumber: 220,
                        columnNumber: 502
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/ScrollingShowCase.jsx",
                    lineNumber: 220,
                    columnNumber: 464
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                lineNumber: 220,
                columnNumber: 435
            }, this)
        ]
    }, item.slug, true, {
        fileName: "[project]/src/components/ScrollingShowCase.jsx",
        lineNumber: 220,
        columnNumber: 10
    }, this);
}
function _ScrollingShowcaseScrollSectionsMapItemBulletsMap(b, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        className: "flex gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sky-500",
                children: "•"
            }, void 0, false, {
                fileName: "[project]/src/components/ScrollingShowCase.jsx",
                lineNumber: 223,
                columnNumber: 45
            }, this),
            b
        ]
    }, i, true, {
        fileName: "[project]/src/components/ScrollingShowCase.jsx",
        lineNumber: 223,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "ScrollingShowcase");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data/modalities.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"modalities":[{"id":"training","title":"Training","shortDescription":"Structured learning programs to build core skills.","fullDescription":"Training is an organized process of teaching skills, imparting knowledge, and building competencies. We work closely with business and HR teams to design result-oriented training programs delivered by expert facilitators.","image":"/images/Training.webp"},{"id":"coaching","title":"Coaching","shortDescription":"One-on-one and group coaching for growth.","fullDescription":"Coaching is a collaborative process that builds awareness and unlocks potential. It can be delivered as a standalone engagement or embedded within leadership and development programs.","image":"/images/Coaching.webp"},{"id":"mentoring","title":"Mentoring","shortDescription":"Learning from experienced leaders.","fullDescription":"Mentoring connects experienced professionals with emerging talent to share insights, guidance, and real-world wisdom that accelerates professional growth.","image":"/images/Mentoring.webp"},{"id":"facilitation","title":"Facilitation","shortDescription":"Guided group processes for clarity.","fullDescription":"Facilitation helps groups achieve outcomes such as decision-making, alignment, and problem-solving through structured, participative processes.","image":"/images/Facilitation.webp"},{"id":"consulting","title":"Consulting","shortDescription":"Expert advice and solutions.","fullDescription":"Consulting involves diagnosing business challenges and delivering practical, actionable solutions that drive performance and organizational effectiveness.","image":"/images/Consulting.webp"}]});}),
"[project]/src/components/ModalitiesSection.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ModalitiesSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$modalities$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/modalities.json (json)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ModalitiesSection() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    if ($[0] !== "ab05fe2cdadecfb7db62d76b989083eea67fe8ffc5238c961b9fa0653804e324") {
        for(let $i = 0; $i < 26; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ab05fe2cdadecfb7db62d76b989083eea67fe8ffc5238c961b9fa0653804e324";
    }
    const { modalities } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$modalities$2e$json__$28$json$29$__["default"];
    const [activeId, setActiveId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(modalities[0].id);
    let t0;
    if ($[1] !== activeId) {
        t0 = modalities.find({
            "ModalitiesSection[modalities.find()]": (m)=>m.id === activeId
        }["ModalitiesSection[modalities.find()]"]);
        $[1] = activeId;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const activeItem = t0;
    let t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl font-extrabold text-slate-900",
            children: "OUR MODALITIES"
        }, void 0, false, {
            fileName: "[project]/src/components/ModalitiesSection.jsx",
            lineNumber: 34,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mt-3 text-slate-600",
            children: "A suite of learning experiences designed to meet people where they are."
        }, void 0, false, {
            fileName: "[project]/src/components/ModalitiesSection.jsx",
            lineNumber: 35,
            columnNumber: 10
        }, this);
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    let t3;
    if ($[5] !== activeId) {
        t3 = modalities.map({
            "ModalitiesSection[modalities.map()]": (item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: {
                                "ModalitiesSection[modalities.map() > <button>.onClick]": ()=>setActiveId(item.id)
                            }["ModalitiesSection[modalities.map() > <button>.onClick]"],
                            className: `w-full rounded-xl p-4 text-left transition ${activeId === item.id ? "bg-gradient-to-r from-orange-100 to-pink-100 ring-2 ring-orange-300" : "bg-white ring-1 ring-slate-200 hover:bg-slate-50"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-semibold text-slate-900",
                                    children: item.title
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ModalitiesSection.jsx",
                                    lineNumber: 47,
                                    columnNumber: 276
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-1 text-sm text-slate-600",
                                    children: item.shortDescription
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ModalitiesSection.jsx",
                                    lineNumber: 47,
                                    columnNumber: 346
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ModalitiesSection.jsx",
                            lineNumber: 45,
                            columnNumber: 73
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            children: activeId === item.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                initial: {
                                    opacity: 0,
                                    height: 0
                                },
                                animate: {
                                    opacity: 1,
                                    height: "auto"
                                },
                                exit: {
                                    opacity: 0,
                                    height: 0
                                },
                                transition: {
                                    duration: 0.3
                                },
                                className: "overflow-hidden px-4 pt-3 text-sm text-slate-700",
                                children: [
                                    item.fullDescription,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative mt-4 h-56 w-full overflow-hidden rounded-2xl shadow-lg md:hidden",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                src: item.image,
                                                alt: item.title,
                                                fill: true,
                                                sizes: "100vw",
                                                className: "object-cover"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ModalitiesSection.jsx",
                                                lineNumber: 58,
                                                columnNumber: 188
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ModalitiesSection.jsx",
                                                lineNumber: 58,
                                                columnNumber: 282
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute bottom-3 left-3 text-white",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-sm font-semibold",
                                                    children: item.title
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ModalitiesSection.jsx",
                                                    lineNumber: 58,
                                                    columnNumber: 417
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ModalitiesSection.jsx",
                                                lineNumber: 58,
                                                columnNumber: 364
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ModalitiesSection.jsx",
                                        lineNumber: 58,
                                        columnNumber: 97
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ModalitiesSection.jsx",
                                lineNumber: 47,
                                columnNumber: 467
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModalitiesSection.jsx",
                            lineNumber: 47,
                            columnNumber: 425
                        }, this)
                    ]
                }, item.id, true, {
                    fileName: "[project]/src/components/ModalitiesSection.jsx",
                    lineNumber: 45,
                    columnNumber: 54
                }, this)
        }["ModalitiesSection[modalities.map()]"]);
        $[5] = activeId;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "md:w-1/2",
            children: [
                t1,
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 space-y-4",
                    children: t3
                }, void 0, false, {
                    fileName: "[project]/src/components/ModalitiesSection.jsx",
                    lineNumber: 67,
                    columnNumber: 44
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ModalitiesSection.jsx",
            lineNumber: 67,
            columnNumber: 10
        }, this);
        $[7] = t3;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    let t6;
    let t7;
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            opacity: 0,
            scale: 0.95
        };
        t6 = {
            opacity: 1,
            scale: 1
        };
        t7 = {
            opacity: 0,
            scale: 0.95
        };
        t8 = {
            duration: 0.4
        };
        $[9] = t5;
        $[10] = t6;
        $[11] = t7;
        $[12] = t8;
    } else {
        t5 = $[9];
        t6 = $[10];
        t7 = $[11];
        t8 = $[12];
    }
    let t9;
    if ($[13] !== activeItem.image || $[14] !== activeItem.title) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: activeItem.image,
            alt: activeItem.title,
            fill: true,
            sizes: "50vw",
            className: "object-cover"
        }, void 0, false, {
            fileName: "[project]/src/components/ModalitiesSection.jsx",
            lineNumber: 105,
            columnNumber: 10
        }, this);
        $[13] = activeItem.image;
        $[14] = activeItem.title;
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"
        }, void 0, false, {
            fileName: "[project]/src/components/ModalitiesSection.jsx",
            lineNumber: 114,
            columnNumber: 11
        }, this);
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    if ($[17] !== activeItem.title) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute bottom-4 left-4 text-white",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-xl font-semibold",
                children: activeItem.title
            }, void 0, false, {
                fileName: "[project]/src/components/ModalitiesSection.jsx",
                lineNumber: 121,
                columnNumber: 64
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ModalitiesSection.jsx",
            lineNumber: 121,
            columnNumber: 11
        }, this);
        $[17] = activeItem.title;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] !== activeItem.id || $[20] !== t11 || $[21] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "hidden md:block md:w-1/2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                mode: "wait",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: t5,
                    animate: t6,
                    exit: t7,
                    transition: t8,
                    className: "relative h-100 w-full overflow-hidden rounded-3xl shadow-xl mt-40 ml-10",
                    children: [
                        t9,
                        t10,
                        t11
                    ]
                }, activeItem.id, true, {
                    fileName: "[project]/src/components/ModalitiesSection.jsx",
                    lineNumber: 129,
                    columnNumber: 82
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ModalitiesSection.jsx",
                lineNumber: 129,
                columnNumber: 53
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ModalitiesSection.jsx",
            lineNumber: 129,
            columnNumber: 11
        }, this);
        $[19] = activeItem.id;
        $[20] = t11;
        $[21] = t9;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] !== t12 || $[24] !== t4) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-white py-16",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto max-w-6xl px-4 md:flex md:gap-12",
                children: [
                    t4,
                    t12
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModalitiesSection.jsx",
                lineNumber: 139,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ModalitiesSection.jsx",
            lineNumber: 139,
            columnNumber: 11
        }, this);
        $[23] = t12;
        $[24] = t4;
        $[25] = t13;
    } else {
        t13 = $[25];
    }
    return t13;
}
_s(ModalitiesSection, "SJEggY0y7ZU5oV3uOUPC1P8yV1Q=");
_c = ModalitiesSection;
var _c;
__turbopack_context__.k.register(_c, "ModalitiesSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_60284ba6._.js.map