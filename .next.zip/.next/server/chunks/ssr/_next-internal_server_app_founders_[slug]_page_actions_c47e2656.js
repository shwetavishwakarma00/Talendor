module.exports=[46663,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_founders_%5Bslug%5D_page_actions_c47e2656.js.map