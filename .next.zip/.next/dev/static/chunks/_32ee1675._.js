(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/data/services.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"strategic-hr-consulting":{"title":"Strategic HR Consulting Services","sections":[{"heading":"Executive & Leadership Services","items":["Executive Search: Identifying and onboarding transformational senior talent","Virtual CHRO / CLO Services: Fractional leadership support for HR & Learning strategy","M&A, Culture shaping, Change management, and performance alignment"]},{"heading":"Unleashing Talent Potential","items":["Talent Assessment & Identification","Succession Planning & Critical Role Mapping & Career Track Design","Development & Performance Improvement Planning","Curated Learning Journeys: Personalized capability-building pathways"]},{"heading":"Future-Ready Organization","items":["Organization Development (OD): Capability, agility & effectiveness enhancement","Culture Development & Transformation: Purpose-driven engagement & alignment","Structural Efficiency & Effectiveness: Optimization of systems, roles & workflows","Change Management: Strategic, behavioral, and people-centered change enablement"]},{"heading":"Business-Enabling HR Strategy","items":["HR Strategy Development: Aligning people plans to business priorities","HR Diagnostics & Audits: Assessing maturity, gaps, and readiness","HR Function Set-Up: Building HR functions enabling growth, culture & compliance","Future of Work: DEI, Wellbeing & Sustainability frameworks"]}]},"leadership-development-journeys":{"title":"Leadership Development Journeys","sections":[{"heading":"Foundational Leadership Programs","items":["New Manager Bootcamps","Leadership Essentials Workshops","Manager as Coach Training","Emotional Intelligence & Self-Awareness Labs"]},{"heading":"Advanced Leadership Development","items":["Strategic Thinking & Decision-Making","Influencing Without Authority","Cross-Functional Leadership Labs","Leading in Complexity / VUCA / BANI World"]},{"heading":"Executive & C-Suite Development","items":["Executive Coaching (1:1 or Group)","Leadership Masterclasses & Retreats","Boardroom Readiness Labs","Authentic Leadership & Legacy Building"]},{"heading":"Global, Inclusive & Cross-Cultural Leadership","items":["Inclusive Leadership & Bias Awareness Workshops","Global Mindset & Cultural Intelligence Training","Leading Multigenerational & Multicultural Teams","Aligning Leadership with ESG & Sustainability Goals"]},{"heading":"Discovering Self & Executive Presence","items":["Leadership Mindset & Identity","Executive Presence & Influence","Emotional Intelligence & Mindfulness","Stress Tolerance & Resilience","Adaptability in VUCA / BANI Environments"]},{"heading":"Leading Teams & Building Thriving Cultures","items":["High-Performing & Self-Organized Teams","Team Effectiveness & Psychological Safety","Multigenerational & Multicultural Leadership","Problem-Solving & Critical Thinking","Empathetic Communication & Coaching"]},{"heading":"Thriving in Business Leadership","items":["Ownership & Accountability","Strategic Thinking, Planning & Execution","Strategic Selling & Influencing Without Authority","Key Account & Stakeholder Management","Project Leadership & Execution Excellence"]}]},"reskilling-programs":{"title":"Reskilling Programs","sections":[{"heading":"Leading Self in VUCA / BANI","items":["Problem-Solving, Critical Thinking & Adaptability","Resilience, Stress Tolerance & Flexibility","Emotional Intelligence & Empathetic Leadership","Mindfulness & Mental Agility"]},{"heading":"Strategic Capability & Commercial Impact","items":["Ownership, Accountability & Decision-Making","Strategic Thinking, Planning & Execution","Intercultural Awareness & Global Leadership","Strategic Selling, Negotiation & Influencing","Key Account Management","Project Management & Delivery Agility"]},{"heading":"Self-Mastery & Mindset Expansion","items":["Inner Mastery: Clarifying clarity, values & confidence","Reflective Self-Development & Journaling Practices","Neuro Leadership Fundamentals","Brain-Based Personal Development Strategies"]},{"heading":"Understanding Generational Differences","items":["Generational DNA, Traits & Motivators","Debunking Myths & Biases Across Generations","Multigenerational Mix: Leveraging Diverse Strengths"]},{"heading":"Working Effectively with Gen Z","items":["Gen Z Communication: Fast feedback & transparency","Purpose & Personal Growth Pathways","Digital Dexterity & Entrepreneurial Mindset","Authenticity & Inclusion at Work"]},{"heading":"Reverse Mentoring & Inclusive Innovation","items":["Reverse Mentoring Programs","Generational Innovation Circles","Intergenerational Decision-Making Practices"]},{"heading":"Working Smarter","items":["Time Management & Productivity Hacks","Organizing Work Efficiently","Effective Hybrid Communication","Giving & Receiving Feedback","Understanding Different Personalities & Work Styles"]}]},"team-development-journeys":{"title":"Team Development Journeys","sections":[{"heading":"Foundations of Team Happiness & Trust","items":["Psychological Safety & Belonging","Purpose-Driven Team Vision","Empathy & Active Listening Practices","Celebration & Recognition Rituals"]},{"heading":"Building Multigenerational Teams","items":["Motivation & Engagement Across Ages","Flexible Leadership Styles","Cross-Generational Collaboration Labs","Conflict Management & Communication Styles"]},{"heading":"Thriving & High-Performing Teams","items":["Building High-Performing Teams","Fostering Self-Organized & Autonomous Teams","Enhancing Teamwork Effectiveness","Psychological Safety & Empathic Communication"]}]},"wellbeing":{"title":"Wellbeing","sections":[{"heading":"Retreats","items":["Soulful, immersive experiences to reconnect with inner peace"]},{"heading":"Stress Management","items":["Coping strategies, mindfulness & breathing techniques"]},{"heading":"Emotional Intelligence","items":["Self-awareness, empathy & relationship management"]},{"heading":"Resilience Building","items":["Adaptability, grit & positive psychology"]},{"heading":"Work-Life Balance","items":["Time management, boundary setting & digital detox"]},{"heading":"Financial Wellness","items":["Agile financial planning for life goals"]},{"heading":"Social Connection","items":["Team bonding, peer support & community engagement"]}]},"coaching-mentoring":{"title":"Key Coaching & Mentoring Offerings","sections":[{"heading":"Coaching","items":["Individual Development Coaching","Onboarding Transition Coaching","Job Role Transition Coaching","Leadership Development Coaching","Career Coaching","Business Coaching"]},{"heading":"Mentoring","items":["Young HR Professional Mentoring","Future HR Leader Mentoring","First-Time Manager Mentoring","Future People Leader Mentoring","Executive Leader Mentoring"]}]},"customer-delight-programs":{"title":"Customer Delight Programs","sections":[{"heading":"Moments of Magic","items":["Grooming & Etiquette","Basic Communication & Listening Skills","Handling Difficult Customers & Situations","Complaint Resolution & Customer Feedback"]},{"heading":"Customer Delight Journey","items":["Understanding & Reducing Customer Pain Points","Empathetic Servicing","Handling Complaints with Grace","Creating Surprise & WOW Moments"]},{"heading":"Service Excellence","items":["Communication Mastery","Customer Delight & Experience Design","Customer Feedback & Continuous Improvement","Train-the-Trainer Programs"]}]}});}),
"[project]/src/app/services/[slug]/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ServicePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$services$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/services.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ServicePage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(25);
    if ($[0] !== "e14238680b988943fc47d119d95b745ea5187f272d4fa4138e4da786a28a8442") {
        for(let $i = 0; $i < 25; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e14238680b988943fc47d119d95b745ea5187f272d4fa4138e4da786a28a8442";
    }
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const [service, setService] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t0;
    let t1;
    if ($[1] !== params) {
        t0 = ({
            "ServicePage[useEffect()]": ()=>{
                if (!params?.slug) {
                    return;
                }
                const slug = params.slug;
                const data = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$services$2e$json__$28$json$29$__["default"][slug];
                setService(data);
            }
        })["ServicePage[useEffect()]"];
        t1 = [
            params
        ];
        $[1] = params;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    if (!service) {
        let t2;
        if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-h-screen flex items-center justify-center bg-slate-950",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-xl font-semibold text-slate-200",
                    children: "Loading service..."
                }, void 0, false, {
                    fileName: "[project]/src/app/services/[slug]/page.js",
                    lineNumber: 43,
                    columnNumber: 88
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/services/[slug]/page.js",
                lineNumber: 43,
                columnNumber: 12
            }, this);
            $[4] = t2;
        } else {
            t2 = $[4];
        }
        return t2;
    }
    let t2;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "pointer-events-none absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950",
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 52,
            columnNumber: 10
        }, this);
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "inline-flex items-center rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs md:text-sm font-medium tracking-wide uppercase text-slate-200",
            children: "Services"
        }, void 0, false, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 59,
            columnNumber: 10
        }, this);
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== service.title) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "mt-5 text-3xl md:text-5xl font-bold tracking-tight",
            children: service.title
        }, void 0, false, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[7] = service.title;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] !== service.subtitle) {
        t5 = service.subtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mt-4 max-w-2xl mx-auto text-sm md:text-lg text-slate-300",
            children: service.subtitle
        }, void 0, false, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 74,
            columnNumber: 30
        }, this);
        $[9] = service.subtitle;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    let t6;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "inline-flex items-center gap-2 rounded-full bg-white/5 px-3 py-1",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "h-1.5 w-1.5 rounded-full bg-emerald-400"
                }, void 0, false, {
                    fileName: "[project]/src/app/services/[slug]/page.js",
                    lineNumber: 82,
                    columnNumber: 93
                }, this),
                "Tailored for your business"
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 82,
            columnNumber: 10
        }, this);
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    let t7;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-6 flex flex-wrap items-center justify-center gap-3 text-xs md:text-sm text-slate-300",
            children: [
                t6,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "inline-flex items-center gap-2 rounded-full bg-white/5 px-3 py-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "h-1.5 w-1.5 rounded-full bg-orange-400"
                        }, void 0, false, {
                            fileName: "[project]/src/app/services/[slug]/page.js",
                            lineNumber: 89,
                            columnNumber: 202
                        }, this),
                        "Expert-led implementation"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/services/[slug]/page.js",
                    lineNumber: 89,
                    columnNumber: 119
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 89,
            columnNumber: 10
        }, this);
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    let t8;
    if ($[13] !== t4 || $[14] !== t5) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "relative md:py-8 pt-15 overflow-hidden bg-slate-950 text-slate-50",
            children: [
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative max-w-5xl mx-auto px-4 pt-16 pb-12 md:pt-24 md:pb-16 text-center",
                    children: [
                        t3,
                        t4,
                        t5,
                        t7
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/services/[slug]/page.js",
                    lineNumber: 96,
                    columnNumber: 101
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 96,
            columnNumber: 10
        }, this);
        $[13] = t4;
        $[14] = t5;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] !== service.sections) {
        let t10;
        if ($[18] !== service.sections.length) {
            t10 = ({
                "ServicePage[service.sections.map()]": (section, index)=>{
                    const isLast = index === service.sections.length - 1;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "relative rounded-2xl border border-slate-200 bg-white px-5 py-8 md:px-8 md:py-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-x-6 -top-0.5 h-0.5 bg-gradient-to-r from-orange-400 via-orange-500 to-orange-400 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 110,
                                columnNumber: 132
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-6 md:flex-row md:items-center md:justify-between mb-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-center md:text-left max-w-2xl mx-auto md:mx-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-2xl md:text-3xl font-semibold text-slate-900",
                                                children: section.heading
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/services/[slug]/page.js",
                                                lineNumber: 110,
                                                columnNumber: 417
                                            }, this),
                                            section.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-3 text-sm md:text-base text-slate-600",
                                                children: section.description
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/services/[slug]/page.js",
                                                lineNumber: 110,
                                                columnNumber: 529
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/services/[slug]/page.js",
                                        lineNumber: 110,
                                        columnNumber: 349
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-3 gap-3 text-center md:text-right text-xs md:text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "rounded-xl bg-slate-50 px-3 py-2 border border-slate-200",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-slate-500",
                                                        children: "Items"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/services/[slug]/page.js",
                                                        lineNumber: 110,
                                                        columnNumber: 776
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 font-semibold text-slate-900",
                                                        children: section.items.length
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/services/[slug]/page.js",
                                                        lineNumber: 110,
                                                        columnNumber: 815
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/services/[slug]/page.js",
                                                lineNumber: 110,
                                                columnNumber: 702
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "rounded-xl bg-orange-50 px-3 py-2 border border-orange-100",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-orange-700/80",
                                                        children: "Completion"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/services/[slug]/page.js",
                                                        lineNumber: 110,
                                                        columnNumber: 972
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 font-semibold text-orange-700",
                                                        children: "92%"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/services/[slug]/page.js",
                                                        lineNumber: 110,
                                                        columnNumber: 1020
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/services/[slug]/page.js",
                                                lineNumber: 110,
                                                columnNumber: 896
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "rounded-xl bg-emerald-50 px-3 py-2 border border-emerald-100",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-emerald-700/80",
                                                        children: "Impact"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/services/[slug]/page.js",
                                                        lineNumber: 110,
                                                        columnNumber: 1161
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 font-semibold text-emerald-700",
                                                        children: "High"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/services/[slug]/page.js",
                                                        lineNumber: 110,
                                                        columnNumber: 1206
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/services/[slug]/page.js",
                                                lineNumber: 110,
                                                columnNumber: 1083
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/services/[slug]/page.js",
                                        lineNumber: 110,
                                        columnNumber: 617
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 110,
                                columnNumber: 260
                            }, this),
                            !isLast ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid gap-5 md:grid-cols-2 lg:grid-cols-3",
                                children: section.items.map(_ServicePageServiceSectionsMapSectionItemsMap)
                            }, void 0, false, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 110,
                                columnNumber: 1294
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid gap-8 lg:grid-cols-[1.1fr,0.9fr] items-start",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-2xl border border-slate-200 bg-slate-50 px-5 py-5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-base font-semibold text-slate-900 mb-3",
                                            children: "Overview"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/services/[slug]/page.js",
                                            lineNumber: 110,
                                            columnNumber: 1569
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-base text-slate-600 mb-4",
                                            children: "A high-level view of how this service is delivered end-to-end."
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/services/[slug]/page.js",
                                            lineNumber: 110,
                                            columnNumber: 1642
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "space-y-3",
                                            children: section.items.map(_ServicePageServiceSectionsMapSectionItemsMap2)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/services/[slug]/page.js",
                                            lineNumber: 110,
                                            columnNumber: 1753
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/services/[slug]/page.js",
                                    lineNumber: 110,
                                    columnNumber: 1494
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 110,
                                columnNumber: 1427
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/src/app/services/[slug]/page.js",
                        lineNumber: 110,
                        columnNumber: 18
                    }, this);
                }
            })["ServicePage[service.sections.map()]"];
            $[18] = service.sections.length;
            $[19] = t10;
        } else {
            t10 = $[19];
        }
        t9 = service.sections.map(t10);
        $[16] = service.sections;
        $[17] = t9;
    } else {
        t9 = $[17];
    }
    let t10;
    if ($[20] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "max-w-8xl mx-auto px-4 py-12 md:py-16 space-y-12 md:space-y-16",
            children: t9
        }, void 0, false, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 126,
            columnNumber: 11
        }, this);
        $[20] = t9;
        $[21] = t10;
    } else {
        t10 = $[21];
    }
    let t11;
    if ($[22] !== t10 || $[23] !== t8) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-slate-50",
            children: [
                t8,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/services/[slug]/page.js",
            lineNumber: 134,
            columnNumber: 11
        }, this);
        $[22] = t10;
        $[23] = t8;
        $[24] = t11;
    } else {
        t11 = $[24];
    }
    return t11;
}
_s(ServicePage, "VHTsBdt5F5vG8ZqQEtjvWA5EmEA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = ServicePage;
function _ServicePageServiceSectionsMapSectionItemsMap2(item_0, i_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        className: "flex gap-3 items-start",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "mt-1 inline-flex h-5 w-5 items-center justify-center rounded-full bg-orange-50 text-[11px] font-semibold text-orange-600",
                children: i_0 + 1
            }, void 0, false, {
                fileName: "[project]/src/app/services/[slug]/page.js",
                lineNumber: 144,
                columnNumber: 59
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-slate-700 leading-relaxed",
                children: item_0
            }, void 0, false, {
                fileName: "[project]/src/app/services/[slug]/page.js",
                lineNumber: 144,
                columnNumber: 214
            }, this)
        ]
    }, i_0, true, {
        fileName: "[project]/src/app/services/[slug]/page.js",
        lineNumber: 144,
        columnNumber: 10
    }, this);
}
function _ServicePageServiceSectionsMapSectionItemsMap(item, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col rounded-2xl border border-slate-200 bg-white px-4 py-4 hover:border-orange-500/70 transition-colors",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-3 mb-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "inline-flex h-9 w-9 items-center justify-center rounded-full bg-orange-50 text-orange-600",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCheckCircle"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/services/[slug]/page.js",
                                    lineNumber: 147,
                                    columnNumber: 359
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 147,
                                columnNumber: 252
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "inline-flex rounded-full bg-orange-50 px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wide text-orange-700",
                                children: [
                                    "Service ",
                                    i + 1
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 147,
                                columnNumber: 402
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/services/[slug]/page.js",
                        lineNumber: 147,
                        columnNumber: 211
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-end gap-0.5 h-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "w-0.5 rounded-full bg-orange-200 h-2"
                            }, void 0, false, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 147,
                                columnNumber: 608
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "w-0.5 rounded-full bg-orange-300 h-3"
                            }, void 0, false, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 147,
                                columnNumber: 665
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "w-0.5 rounded-full bg-orange-400 h-4"
                            }, void 0, false, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 147,
                                columnNumber: 722
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "w-0.5 rounded-full bg-orange-500 h-5"
                            }, void 0, false, {
                                fileName: "[project]/src/app/services/[slug]/page.js",
                                lineNumber: 147,
                                columnNumber: 779
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/services/[slug]/page.js",
                        lineNumber: 147,
                        columnNumber: 564
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/services/[slug]/page.js",
                lineNumber: 147,
                columnNumber: 149
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm md:text-base text-slate-700 leading-relaxed",
                children: item
            }, void 0, false, {
                fileName: "[project]/src/app/services/[slug]/page.js",
                lineNumber: 147,
                columnNumber: 848
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-1 w-full rounded-full bg-slate-200 overflow-hidden",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-full w-4/5 rounded-full bg-gradient-to-r from-orange-500 to-emerald-400"
                    }, void 0, false, {
                        fileName: "[project]/src/app/services/[slug]/page.js",
                        lineNumber: 147,
                        columnNumber: 1017
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/services/[slug]/page.js",
                    lineNumber: 147,
                    columnNumber: 947
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/services/[slug]/page.js",
                lineNumber: 147,
                columnNumber: 925
            }, this)
        ]
    }, i, true, {
        fileName: "[project]/src/app/services/[slug]/page.js",
        lineNumber: 147,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "ServicePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_32ee1675._.js.map