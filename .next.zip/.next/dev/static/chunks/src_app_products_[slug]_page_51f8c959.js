(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c7ad3413._.js",
  "static/chunks/src_app_products_[slug]_page_c7325696.js"
],
    source: "dynamic"
});
